// IDs are append-only within each category, so saved histories survive content updates.
export const WORD_CATEGORIES = [
  { id: 'filmes', label: 'Filmes e séries' },
  { id: 'jogos', label: 'Jogos' },
  { id: 'futebol', label: 'Futebol' },
  { id: 'comidas', label: 'Comidas' },
  { id: 'lugares', label: 'Lugares' },
  { id: 'pop', label: 'Cultura pop' },
  { id: 'objetos', label: 'Objetos e ideias' },
  { id: 'musica', label: 'Música' },
  { id: 'celebridades', label: 'Celebridades' },
];

export const QUESTION_CATEGORIES = [
  { id: 'opinioes', label: 'Opiniões' },
  { id: 'cultura', label: 'Cultura' },
  { id: 'comida', label: 'Comida' },
  { id: 'jogos', label: 'Jogos' },
  { id: 'filmes', label: 'Filmes e séries' },
  { id: 'futebol', label: 'Futebol' },
  { id: 'tecnologia', label: 'Tecnologia' },
  { id: 'grupo', label: 'Sobre o grupo' },
  { id: 'aleatorias', label: 'Aleatórias' },
];

const wordBanks = {
  filmes: `Titanic|Despedida
Jurassic Park|Laboratório
O Rei Leão|Herança
De Volta para o Futuro|Atraso
Matrix|Escolha
Shrek|Pântano
Procurando Nemo|Correnteza
Toy Story|Ciúme
Frozen|Irmãs
Divertida Mente|Memórias
Os Incríveis|Disfarce
Ratatouille|Crítica
WALL-E|Solidão
Avatar|Floresta
Vingadores: Ultimato|Sacrifício
Pantera Negra|Sucessão
Guardiões da Galáxia|Playlist
Homem-Aranha no Aranhaverso|Grafite
Batman: O Cavaleiro das Trevas|Caos
O Senhor dos Anéis|Tentação
Harry Potter e a Pedra Filosofal|Internato
Piratas do Caribe|Maldição
Indiana Jones|Relíquia
Missão Impossível|Infiltração
John Wick|Luto
Clube da Luta|Insônia
A Origem|Camadas
Interestelar|Relógio
O Show de Truman|Rotina
Forrest Gump|Banco de praça
O Diabo Veste Prada|Exigência
Meninas Malvadas|Popularidade
Esqueceram de Mim|Férias
Cidade de Deus|Fotografia
Tropa de Elite|Treinamento
Central do Brasil|Cartas
Breaking Bad|Deserto
Stranger Things|Bicicleta
Friends|Apartamento
Round 6|Dívida`,
  jogos: `Minecraft|Picareta
Fortnite|Construção
The Sims|Vizinhança
Super Mario Bros.|Encanação
Mario Kart|Ultrapassagem
The Legend of Zelda|Exploração
Pokémon|Coleção
Animal Crossing|Vizinhos
Stardew Valley|Estações
Terraria|Subsolo
Grand Theft Auto|Perseguição
Red Dead Redemption|Fronteira
God of War|Paternidade
The Last of Us|Escolta
Uncharted|Ruínas
Tomb Raider|Expedição
Resident Evil|Mansão
Silent Hill|Neblina
Five Nights at Freddy's|Turno
Among Us|Suspeita
Fall Guys|Equilíbrio
Rocket League|Impulso
Counter-Strike|Economia
Valorant|Habilidades
Overwatch|Equipe
League of Legends|Rotas
Dota 2|Território
World of Warcraft|Guilda
Diablo|Saque
Elden Ring|Persistência
Dark Souls|Fogueira
Hollow Knight|Insetos
Cuphead|Contrato
Celeste|Escalada
Hades|Tentativas
Undertale|Piedade
Portal|Atalho
Tetris|Encaixe
Street Fighter|Arcade
Mortal Kombat|Rivalidade`,
  futebol: `Cristiano Ronaldo|Disciplina
Lionel Messi|Canhota
Neymar|Drible
Pelé|Coroa
Diego Maradona|Polêmica
Ronaldo Fenômeno|Arrancada
Ronaldinho Gaúcho|Sorriso
Kaká|Elegância
Zinedine Zidane|Classe
Kylian Mbappé|Velocidade
Erling Haaland|Potência
Vinícius Júnior|Ousadia
Marta|Referência
Formiga|Longevidade
Alexia Putellas|Liderança
Johan Cruyff|Filosofia
Romário|Área
Roberto Carlos|Força
Rogério Ceni|Cobrança
Gianluigi Buffon|Experiência
Manuel Neuer|Antecipação
Flamengo|Multidão
Corinthians|Fiel
Palmeiras|Academia
São Paulo FC|Tradição
Santos FC|Revelações
Vasco da Gama|Navegação
Fluminense|Laranjeiras
Botafogo|Estrela
Grêmio|Imortalidade
Internacional|Beira-rio
Cruzeiro|Constelação
Atlético Mineiro|Galo
Real Madrid|Realeza
Barcelona|Catalunha
Liverpool|Canto
Manchester United|Vermelho
Boca Juniors|Caldeirão
Copa do Mundo|Quatro anos
Libertadores|Viagem`,
  comidas: `Pizza|Queijo
Hambúrguer|Chapa
Sushi|Alga
Churrasco|Brasa
Feijoada|Domingo
Coxinha|Festa
Pastel|Feira
Pão de queijo|Café
Acarajé|Azeite
Tapioca|Recheio
Cuscuz nordestino|Vapor
Moqueca|Panela de barro
Vatapá|Amendoim
Escondidinho|Camadas
Lasanha|Forno
Risoto|Caldo
Nhoque|Batata
Carbonara|Gema
Estrogonofe|Creme
Yakissoba|Wok
Lámen|Tigela
Pad thai|Agridoce
Taco mexicano|Pimenta
Guacamole|Limão
Paella|Açafrão
Fondue|Espeto
Croissant|Folhas
Waffle|Quadradinhos
Panqueca|Frigideira
Brigadeiro|Aniversário
Pudim|Calda
Quindim|Brilho
Churros|Canela
Brownie|Casquinha
Tiramisù|Café forte
Cheesecake|Base crocante
Açaí|Gelado
Sorvete napolitano|Três
Pipoca|Estouro
Batata frita|Crocância`,
  lugares: `Japão|Estações
Itália|Praças
França|Vinhos
Portugal|Azulejos
Espanha|Fim de tarde
Grécia|Ilhas
Egito|Areia
Marrocos|Mercados
África do Sul|Safári
Austrália|Distância
Nova Zelândia|Trilhas
Canadá|Lagos
México|Cores
Argentina|Tango
Chile|Montanhas
Peru|Altitude
Colômbia|Café
Jamaica|Ritmo
Islândia|Vapor
Tailândia|Templos
Paris|Romance
Londres|Garoa
Nova York|Pressa
Las Vegas|Apostas
Dubai|Altura
Rio de Janeiro|Orla
São Paulo|Trânsito
Salvador|Ladeiras
Recife|Pontes
Curitiba|Parques
Gramado|Inverno
Manaus|Rios
Brasília|Traçado
Ouro Preto|Pedras
Fernando de Noronha|Mergulho
Lençóis Maranhenses|Lagoas
Cataratas do Iguaçu|Névoa
Deserto do Saara|Horizonte
Antártida|Silêncio
Monte Everest|Fôlego`,
  pop: `Darth Vader|Respiração
Yoda|Paciência
Chewbacca|Pelagem
Superman|Disfarce
Mulher-Maravilha|Laço
Coringa|Baralho
Arlequina|Marreta
Wolverine|Regeneração
Deadpool|Sarcasmo
Thanos|Equilíbrio
Homem de Ferro|Armadura
Capitão América|Princípios
Hulk|Temperamento
Thor|Trovão
Goku|Treinamento
Vegeta|Orgulho
Naruto|Determinação
Sailor Moon|Transformação
Pikachu|Faísca
Sonic|Anéis
Pac-Man|Labirinto
Bob Esponja|Trabalho
Patrick Estrela|Sossego
Lula Molusco|Clarinetista
Homer Simpson|Sofá
Marge Simpson|Penteado
Bart Simpson|Castigo
Scooby-Doo|Lanche
Pernalonga|Provocação
Tom e Jerry|Perseguição
Popeye|Força
Garfield|Preguiça
Snoopy|Imaginação
Mônica|Coelho
Cebolinha|Plano
Magali|Apetite
Chaves|Vila
Chapolin Colorado|Coragem
Barbie|Rosa
Hello Kitty|Laço de cabelo`,
  objetos: `iPhone|Maçã
Kindle|Capítulos
Air fryer|Crocante
AirPods|Estojo
PlayStation|Controle
Nintendo Switch|Portabilidade
GoPro|Aventura
Polaroid|Espera
Walkman|Fita
Disco de vinil|Agulha
Cubo Mágico|Paciência
Lego|Encaixe
Patins|Equilíbrio
Skate|Asfalto
Prancha de surfe|Parafina
Rede de descanso|Balanço
Máquina de escrever|Correção
Ampulheta|Espera
Bússola|Rumo
Telescópio|Distância
Microscópio|Detalhe
Drone|Hélice
Impressora 3D|Camadas
Robô aspirador|Obstáculo
Panela de pressão|Chiado
Garrafa térmica|Temperatura
Cafeteira italiana|Vapor
Mochila de trilha|Peso
Canivete suíço|Imprevisto
Guarda-chuva|Previsão
Fone com cancelamento de ruído|Concentração
Óculos de realidade virtual|Imersão
Esteira de academia|Rotina
Controle remoto|Disputa
Cofrinho|Economia
Passaporte|Carimbo
Cartão de crédito|Limite
Bitcoin|Volatilidade
Pix|Instantâneo
Wi-Fi|Alcance`,
  musica: `Queen|Coro
The Beatles|Quarteto
ABBA|Dança
AC/DC|Energia
Metallica|Peso
Nirvana|Garagem
Pearl Jam|Seattle
Red Hot Chili Peppers|Califórnia
Coldplay|Pulseiras
U2|Estádio
Oasis|Irmãos
Radiohead|Experimento
Pink Floyd|Conceito
Led Zeppelin|Estrada
Guns N' Roses|Bandana
Linkin Park|Mistura
Foo Fighters|Baquetas
Paramore|Franja
Green Day|Rebeldia
Daft Punk|Capacete
BTS|Coreografia
Blackpink|Fãs
Racionais MC's|Narrativa
Legião Urbana|Geração
Titãs|Plural
Os Paralamas do Sucesso|Trio
Skank|Horizonte
Jota Quest|Baile
Charlie Brown Jr.|Skate
O Rappa|Protesto
Sepultura|Intensidade
Barões da Pisadinha|Teclado
Bohemian Rhapsody|Mudanças
Evidências|Negação
Garota de Ipanema|Caminhada
Asa Branca|Saudade
Águas de Março|Chuva
Trem das Onze|Horário
País Tropical|Alegria
Take on Me|Desenho`,
  celebridades: `Anitta|Palco
Ludmilla|Baile
Ivete Sangalo|Carnaval
Claudia Leitte|Trio elétrico
Marília Mendonça|Desabafo
Alcione|Potência
Elza Soares|Resistência
Rita Lee|Irreverência
Caetano Veloso|Poesia
Gilberto Gil|Ritmo
Chico Buarque|Histórias
Djavan|Harmonia
Tim Maia|Grave
Seu Jorge|Timbre
Péricles|Roda
Zeca Pagodinho|Quintal
Taylor Swift|Diário
Beyoncé|Performance
Rihanna|Cosméticos
Lady Gaga|Figurino
Adele|Despedida
Shakira|Dança
Bruno Mars|Balanço
Michael Jackson|Passos
Madonna|Reinvenção
Elvis Presley|Quadril
Freddie Mercury|Bigode
Silvio Santos|Auditório
Xuxa|Infância
Ana Maria Braga|Manhã
Fernanda Montenegro|Prestígio
Fernanda Torres|Expressão
Wagner Moura|Intensidade
Selton Mello|Humor
Lázaro Ramos|Versatilidade
Taís Araújo|Carisma
Viola Davis|Emoção
Meryl Streep|Versatilidade
Tom Hanks|Simpatia
Keanu Reeves|Discrição`,
};

export const WORDS = Object.entries(wordBanks).flatMap(([category, bank]) =>
  bank.split('\n').map((line, index) => {
    const [word, hint] = line.split('|');
    return { id: `w-${category}-${String(index + 1).padStart(3, '0')}`, category, word, hint };
  }),
);

const questionBanks = {
  opinioes: `Qual país você escolheria para morar por cinco anos?
Qual cidade brasileira seria a melhor para passar um mês de férias?
Qual superpoder seria mais útil na vida real?
Qual profissão parece ganhar menos do que merece?
Qual tarefa doméstica você pagaria para nunca mais fazer?
Qual habilidade você escolheria aprender de uma vez, sem praticar?
Qual matéria deveria ter recebido mais atenção na escola?
Qual é o melhor horário para começar a trabalhar?
Qual mês do ano é o melhor para tirar férias?
Qual feriado você gostaria que durasse uma semana?
Qual é o melhor destino para uma primeira viagem internacional?
Qual compra costuma valer a pena mesmo sendo cara?
Qual gasto pequeno mais engana no fim do mês?
Qual cômodo merece mais investimento numa casa?
Qual atividade é melhor fazer sozinho?
Qual é a maior vantagem de trabalhar em casa?
Qual hábito de outras pessoas mais incomoda no cinema?
Qual objeto você salvaria primeiro se só pudesse levar um numa mudança?
Qual profissão você experimentaria por uma semana?
Qual serviço por assinatura é mais difícil de cancelar por vontade própria?
Qual é a melhor idade para aprender a dirigir?
Qual é o pior barulho para ouvir de madrugada?
Qual invenção mais melhorou a vida dentro de casa?
Qual é o melhor presente para alguém que você conhece pouco?`,
  cultura: `Qual cantor brasileiro você escolheria para um show particular?
Qual banda você gostaria de ver ao vivo, incluindo as que já acabaram?
Qual música brasileira todo mundo parece saber cantar?
Qual música não pode faltar numa festa de casamento?
Qual artista tem a voz mais fácil de reconhecer?
Qual é a melhor música para cantar no karaokê?
Qual programa de TV mais marcou sua infância?
Qual desenho animado também funciona muito bem para adultos?
Qual personagem de desenho você reconheceria só pela voz?
Qual livro merecia uma adaptação melhor para o cinema?
Qual escritor brasileiro você indicaria para quem quer começar a ler?
Qual museu ou ponto cultural você teria mais vontade de visitar?
Qual festa popular brasileira parece a mais divertida?
Qual instrumento musical você mais gostaria de tocar bem?
Qual estilo musical combina mais com uma viagem de carro?
Qual música costuma levantar uma festa que estava parada?
Qual cantor ou cantora internacional você traria ao Brasil para um show?
Qual personagem da Turma da Mônica é o mais engraçado?
Qual programa de competição da TV você toparia disputar?
Qual apresentador de TV seria bom anfitrião de um jantar?
Qual dupla sertaneja você escolheria para animar um churrasco?
Qual música brasileira tem a letra mais bonita?
Qual podcast você recomendaria a alguém que nunca ouviu um?
Qual personagem fictício daria a melhor entrevista?`,
  comida: `Qual é o melhor sabor de pizza?
Qual é o melhor refrigerante?
Qual rede de fast-food tem o melhor hambúrguer?
Qual acompanhamento não pode faltar num churrasco?
Qual comida fica melhor no dia seguinte?
Qual sobremesa encerra melhor um almoço em família?
Qual salgado de festa acaba primeiro?
Qual é o melhor recheio de pastel?
Qual prato você pediria no seu restaurante favorito?
Qual fruta rende o melhor suco?
Qual sabor de sorvete você pediria se só pudesse escolher um?
Qual comida vale a pena aprender a fazer em casa?
Qual ingrediente estraga uma pizza para você?
Qual é o melhor lanche para comer de madrugada?
Qual comida brasileira você apresentaria a alguém de outro país?
Qual é o melhor recheio para uma tapioca?
Qual corte de carne é a estrela de um churrasco?
Qual acompanhamento combina mais com estrogonofe?
Qual comida é mais difícil de dividir com outras pessoas?
Qual é a melhor comida de festa junina?
Qual molho melhora quase qualquer sanduíche?
Qual chocolate de mercado você escolheria agora?
Qual comida você prefere pedir a preparar em casa?
Qual é a melhor coisa para comer junto com café?`,
  jogos: `Qual é o melhor jogo para jogar com amigos à distância?
Qual videogame mais marcou sua vida?
Qual jogo você considera mais viciante?
Qual jogo seria o melhor para apresentar a alguém que nunca jogou?
Qual personagem dos games é o mais reconhecível?
Qual jogo tem a melhor trilha sonora?
Qual jogo merecia uma continuação?
Qual jogo de celular melhor passa o tempo numa fila?
Qual jogo você gostaria de esquecer para jogar pela primeira vez de novo?
Qual jogo de corrida é o mais divertido com amigos?
Qual jogo de luta mais rende rivalidade entre amigos?
Qual jogo costuma testar mais a paciência de uma equipe?
Qual jogo de tabuleiro é o melhor para uma noite com amigos?
Qual jogo de cartas você escolheria para levar numa viagem?
Qual jogo tem o mundo mais interessante para explorar?
Qual vilão dos games é o mais marcante?
Qual personagem você escolhe primeiro em Mario Kart?
Qual Pokémon você escolheria como companheiro?
Qual jogo funciona melhor mesmo para quem perdeu a primeira partida?
Qual jogo antigo continua divertido hoje?
Qual jogo dá mais vontade de dizer só mais uma partida?
Qual jogo tem a melhor história?
Qual jogo seria mais divertido se todo este grupo aprendesse a jogar?
Qual item de um videogame você gostaria de ter na vida real?`,
  filmes: `Qual é o melhor filme da Marvel?
Qual filme você sempre para para assistir quando encontra passando?
Qual série tem o melhor primeiro episódio?
Qual série mais merecia um final diferente?
Qual filme de animação você indicaria para qualquer idade?
Qual vilão do cinema é o mais memorável?
Qual personagem de série seria o melhor colega de apartamento?
Qual filme de terror mais dá medo?
Qual comédia você escolheria para assistir com este grupo?
Qual franquia de cinema já teve continuações demais?
Qual filme tem a melhor trilha sonora?
Qual ator ou atriz faz você dar uma chance a um filme?
Qual filme brasileiro você recomendaria primeiro a alguém de fora?
Qual série vale a pena assistir mais de uma vez?
Qual filme você gostaria de ver de novo no cinema?
Qual personagem de Friends é o mais engraçado?
Qual filme de Natal é o mais indispensável?
Qual filme tem a melhor reviravolta?
Qual universo de ficção você gostaria de visitar por um dia?
Qual personagem dos Vingadores é o mais útil numa equipe?
Qual série é a mais difícil de assistir só um episódio?
Qual adaptação de livro para o cinema funcionou melhor?
Qual filme tem o final mais emocionante?
Qual personagem de filme você escolheria para organizar um plano?`,
  futebol: `Quem é o melhor jogador de futebol de todos os tempos?
Quem é o melhor jogador brasileiro que você viu jogar?
Qual clube tem a torcida que mais impressiona no estádio?
Qual seleção, além do Brasil, você costuma torcer para ver jogar?
Qual estádio você mais gostaria de conhecer?
Qual jogador você escolheria para bater um pênalti decisivo?
Qual goleiro você escolheria para defender um pênalti decisivo?
Qual camisa de clube é a mais bonita?
Qual clássico brasileiro você considera mais intenso?
Qual narrador deixa um jogo mais emocionante?
Qual jogador tem a comemoração de gol mais marcante?
Qual seleção tem o uniforme mais bonito?
Qual foi a Copa do Mundo mais marcante para você?
Qual jogador faria mais falta numa pelada do seu time?
Qual clube estrangeiro você acompanharia se tivesse de escolher só um?
Qual jogador aposentado você gostaria de ver jogar hoje?
Qual técnico você escolheria para dirigir a seleção brasileira?
Qual posição é a mais difícil de jogar bem?
Qual jogador é a primeira escolha para cobrar uma falta perto da área?
Qual time brasileiro costuma ser mais difícil de enfrentar em casa?
Qual jogador ficou mais famoso pelo estilo de cabelo?
Qual jogadora de futebol você mais admira?
Qual competição de clubes é a mais emocionante?
Qual jogador você escolheria para uma entrevista de uma hora?`,
  tecnologia: `Qual marca de celular você considera a melhor?
Qual aplicativo você sentiria mais falta se ficasse uma semana sem usar?
Qual aparelho de casa mais merece uma versão inteligente?
Qual recurso de celular você realmente usa todos os dias?
Qual rede social você apagaria primeiro para ganhar tempo livre?
Qual aplicativo você recomendaria a alguém que acabou de ganhar um celular?
Qual é o pior momento para a bateria do celular acabar?
Qual objeto a tecnologia deveria aposentar de vez?
Qual função faria você trocar de celular antes do planejado?
Qual serviço digital é mais irritante quando fica fora do ar?
Qual videogame você compraria se o preço não importasse?
Qual acessório de celular costuma valer o dinheiro gasto?
Qual marca de fone de ouvido você escolheria?
Qual tarefa você mais gostaria de automatizar em casa?
Qual senha as pessoas deveriam parar de usar?
Qual aplicativo mais ajuda numa viagem para uma cidade desconhecida?
Qual invenção recente você teria achado impossível quando criança?
Qual aparelho você levaria para uma viagem de trabalho além do celular?
Qual problema com internet é o mais irritante?
Qual site ou aplicativo é o melhor para aprender algo novo?
Qual produto tecnológico mais decepciona quando é muito barato?
Qual aparelho eletrônico você gostaria de consertar em vez de trocar?
Qual recurso de mensagens mais ajuda a evitar mal-entendidos?
Qual tecnologia você gostaria que fosse mais acessível para todo mundo?`,
  grupo: `Quem daqui se daria melhor morando sozinho?
Quem daqui teria mais chance de esquecer onde estacionou o carro?
Quem daqui seria melhor negociando um preço?
Quem daqui demoraria mais para responder uma mensagem?
Quem daqui gastaria mais numa viagem?
Quem daqui parece ter mais paciência?
Quem daqui teria mais chance de ganhar dinheiro com uma ideia inesperada?
Quem daqui seria melhor organizando uma viagem?
Quem daqui provavelmente chegaria mais cedo a um compromisso?
Quem daqui teria mais chance de comprar algo caro e se arrepender?
Quem daqui escolheria melhor o restaurante para o grupo?
Quem daqui faria a mala com mais antecedência?
Quem daqui conseguiria viajar só com uma mochila?
Quem daqui provavelmente levaria comida para uma viagem de carro?
Quem daqui seria a melhor companhia para passar horas numa fila?
Quem daqui teria mais facilidade para aprender outro idioma?
Quem daqui lembraria do aniversário de todo mundo?
Quem daqui demoraria mais para escolher algo no cardápio?
Quem daqui faria amizade mais rápido num lugar novo?
Quem daqui conseguiria montar um móvel sem pedir ajuda?
Quem daqui saberia encontrar o melhor desconto?
Quem daqui cuidaria melhor das plantas de alguém em viagem?
Quem daqui teria mais chance de começar um hobby e comprar todo o equipamento?
Quem daqui escolheria a melhor playlist para uma viagem?
Quem daqui teria mais paciência para ensinar alguém a dirigir?
Quem daqui seria melhor resolvendo um imprevisto numa festa?
Quem daqui faria mais pesquisa antes de comprar um celular?
Quem daqui teria mais chance de perder a hora por continuar conversando?
Quem daqui cozinharia o melhor jantar com o que já tem na geladeira?
Quem daqui conseguiria ficar mais tempo sem olhar o celular?
Quem daqui seria a melhor pessoa para guardar um segredo?
Quem daqui toparia uma viagem decidida na véspera?
Quem daqui seria melhor explicando as regras de um jogo?
Quem daqui teria mais chance de se emocionar com um filme?
Quem daqui perceberia primeiro uma mudança no ambiente?
Quem daqui seria melhor fazendo uma apresentação sem ensaiar?
Quem daqui provavelmente dormiria primeiro numa viagem de ônibus?
Quem daqui escolheria o melhor presente para outra pessoa?
Quem daqui teria mais disciplina para aprender um instrumento?
Quem daqui manteria a calma se a viagem tivesse um atraso de seis horas?`,
  aleatorias: `Qual lugar você escolheria para ver o pôr do sol?
Qual cheiro lembra mais a casa da sua infância?
Qual produto de supermercado acaba mais rápido em casa?
Qual animal seria o mais difícil de cuidar dentro de um apartamento?
Qual peça de roupa é mais difícil de comprar pela internet?
Qual objeto você costuma procurar bem na hora de sair?
Qual loja é a mais difícil de entrar sem comprar nada?
Qual é o melhor lugar para sentar num cinema?
Qual é o melhor lugar para sentar num avião?
Qual atividade combina mais com um domingo chuvoso?
Qual comida tem o cheiro mais tentador quando alguém prepara?
Qual esporte parece fácil até você tentar praticar?
Qual aparelho costuma quebrar na pior hora possível?
Qual lembrança de viagem vale mais a pena trazer?
Qual é o melhor destino para uma viagem de fim de semana com amigos?
Qual pequeno luxo melhora mais uma manhã comum?
Qual tarefa sempre parece levar menos tempo do que realmente leva?
Qual objeto deveria vir obrigatoriamente com um localizador?
Qual fila é a mais chata de enfrentar?
Qual lugar público mais precisa de silêncio?
Qual habilidade ajuda mais quando a internet acaba?
Qual lembrança da escola você gostaria de reviver por um dia?
Qual compra você preferiria testar por uma semana antes de pagar?
Qual competição esportiva você gostaria de assistir pessoalmente?`,
};

export const QUESTIONS = Object.entries(questionBanks).flatMap(([category, bank]) =>
  bank.split('\n').map((text, index) => ({
    id: `q-${category}-${String(index + 1).padStart(3, '0')}`,
    category,
    text,
    group: category === 'grupo',
  })),
);


// Banco inicial do jogo de pistas proibidas. Cada carta tem uma palavra-alvo e quatro termos vetados.
const tabooBank = `Abacaxi|Fruta|Casca|Amarelo|Doce
Aeroporto|Avião|Viagem|Embarque|Pista
Academia|Treino|Musculação|Peso|Exercício
Ar-condicionado|Frio|Calor|Controle|Temperatura
Arco-íris|Cores|Chuva|Céu|Ponte
Bateria|Celular|Carga|Energia|Carregar
Bicicleta|Pedalar|Roda|Guidão|Capacete
Bolo|Aniversário|Fatia|Doce|Forno
Cachorro|Cão|Latir|Animal|Pet
Café|Bebida|Xícara|Manhã|Cafeína
Cama|Dormir|Quarto|Travesseiro|Colchão
Câmera|Foto|Lente|Fotografar|Imagem
Caneta|Escrever|Tinta|Papel|Lápis
Carro|Dirigir|Roda|Motor|Veículo
Chave|Porta|Fechadura|Abrir|Metal
Churrasco|Carne|Grelha|Fogo|Espeto
Chuva|Água|Nuvem|Molhado|Guarda-chuva
Cinema|Filme|Tela|Pipoca|Ingresso
Computador|Teclado|Mouse|Monitor|PC
Controle remoto|Televisão|Botão|Canal|Pilha
Copo|Beber|Vidro|Água|Recipiente
Coração|Sangue|Bater|Órgão|Amor
Dança|Dançar|Música|Passos|Ritmo
Dentista|Dente|Consultório|Boca|Aparelho
Despertador|Acordar|Hora|Alarme|Manhã
Dinossauro|Extinto|Fóssil|Jurássico|Tiranossauro
Elevador|Prédio|Andar|Subir|Botão
Escova de dentes|Pasta|Boca|Higiene|Cerdas
Espelho|Reflexo|Rosto|Vidro|Olhar
Estádio|Futebol|Torcida|Jogo|Arquibancada
Fone de ouvido|Música|Som|Ouvir|Bluetooth
Geladeira|Frio|Cozinha|Comida|Congelador
Girassol|Flor|Sol|Amarelo|Planta
Hambúrguer|Pão|Carne|Lanche|Queijo
Hospital|Médico|Doente|Enfermeiro|Emergência
Internet|Wi-Fi|Conexão|Site|Rede
Janela|Vidro|Casa|Abrir|Cortina
Lâmpada|Luz|Acender|Eletricidade|Escuro
Lasanha|Massa|Queijo|Forno|Molho
Livro|Ler|Páginas|História|Biblioteca
Lua|Noite|Céu|Terra|Satélite
Mala|Viagem|Roupa|Bagagem|Zíper
Micro-ondas|Esquentar|Comida|Cozinha|Minutos
Minecraft|Blocos|Creeper|Construir|Minério
Mochila|Costas|Escola|Zíper|Material
Montanha-russa|Parque|Brinquedo|Velocidade|Trilho
Moto|Capacete|Duas rodas|Motor|Pilotar
Óculos|Enxergar|Lente|Rosto|Armação
Ovo|Galinha|Casca|Fritar|Cozinhar
Panela|Fogão|Cozinhar|Tampa|Alimento
Papel higiênico|Banheiro|Rolo|Limpar|Papel
Parque|Árvore|Grama|Brincar|Praça
Passaporte|País|Viagem|Documento|Aeroporto
Pato|Animal|Lago|Quack|Pena
Piano|Teclas|Música|Instrumento|Tocar
Pizza|Queijo|Massa|Fatia|Calabresa
Planeta|Terra|Espaço|Sistema solar|Astronomia
Praia|Mar|Areia|Sol|Onda
Professor|Escola|Aluno|Aula|Ensinar
Relógio|Hora|Ponteiro|Pulso|Tempo
Robô|Máquina|Automático|Metal|Inteligência artificial
Sanduíche|Pão|Recheio|Lanche|Misto
Sapato|Pé|Calçado|Tênis|Cadarço
Semáforo|Trânsito|Vermelho|Verde|Carro
Sorvete|Gelado|Casquinha|Doce|Freezer
Super-herói|Poder|Vilão|Fantasia|Salvar
Teclado|Digitar|Computador|Teclas|Escrever
Telefone|Ligar|Celular|Chamada|Número
Televisão|Tela|Controle|Canal|Assistir
Tênis|Esporte|Raquete|Quadra|Bola
Tomada|Energia|Plugue|Parede|Eletricidade
Tubarão|Mar|Dente|Peixe|Barbatana
Vampiro|Sangue|Morcego|Dentes|Drácula
Ventilador|Vento|Calor|Pás|Ligar
Violão|Cordas|Música|Tocar|Instrumento
Vulcão|Lava|Erupção|Montanha|Magma
WhatsApp|Mensagem|Aplicativo|Verde|Conversar
YouTube|Vídeo|Canal|Assistir|Inscrever-se
Zumbi|Morto-vivo|Cérebro|Apocalipse|Monstro
Batman|Morcego|Gotham|Bruce Wayne|Herói
Barbie|Boneca|Rosa|Ken|Brinquedo
Bob Esponja|Fenda do Biquíni|Patrick|Abacaxi|Desenho
Cinderela|Sapatinho|Princesa|Abóbora|Conto de fadas
Coringa|Batman|Vilão|Palhaço|Gotham
Darth Vader|Star Wars|Luke|Máscara|Lado sombrio
Harry Potter|Bruxo|Hogwarts|Varinha|Voldemort
Homem-Aranha|Teia|Peter Parker|Marvel|Aranha
Mickey Mouse|Disney|Orelhas|Rato|Minie
Shrek|Burro|Ogro|Fiona|Pântano
Sonic|Azul|Ouriço|Velocidade|Sega
TikTok|Dancinha|Vídeo|Aplicativo|Rolagem
Instagram|Foto|Stories|Rede social|Curtida
Pix|Banco|Transferência|Dinheiro|Chave
Enem|Prova|Vestibular|Redação|Questão
Férias|Descanso|Viagem|Praia|Trabalho
Procrastinação|Adiar|Depois|Preguiça|Tarefa
Soneca|Dormir|Cochilo|Cansaço|Despertar
Chinelo|Pé|Sandália|Havaianas|Calçado
Chiclete|Mascar|Bala|Goma|Boca
Pipoca|Milho|Cinema|Estourar|Manteiga
Melancia|Fruta|Verão|Sementes|Vermelha
Morango|Fruta|Vermelho|Doce|Semente
Pinguim|Gelo|Antártida|Ave|Preto e branco
Girafa|Pescoço|Alta|Manchas|Animal
Polvo|Oito|Tentáculos|Mar|Molusco
Canguru|Austrália|Bolsa|Pular|Animal
Formiga|Inseto|Colônia|Pequena|Açúcar
Abelha|Mel|Ferrão|Colmeia|Inseto
`;
export const TABOO_CARDS = tabooBank.trim().split('\n').map((line, index) => {
  const [word, ...forbidden] = line.split('|');
  return { id: `taboo-${String(index + 1).padStart(3, '0')}`, word, forbidden };
});
