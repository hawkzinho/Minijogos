import { WORD_CATEGORIES, QUESTION_CATEGORIES, WORDS, QUESTIONS, TABOO_CARDS } from './content.js';
import { createImpostor, openImpostor, finishImpostorReveal, backImpostor, revealImpostorResult,
  createThought, openThought, submitThought, nextThought, createTimer, startTimer, recordTimer,
  interruptTimer, ranking, formatTime, normalizeText } from './engine.js';
import { loadState, saveState, setAwake, initPlatform, installApp, isOfflineReady } from './platform.js';
import { icon } from './icons.js';

const app = document.querySelector('#app');
const modal = document.querySelector('#modal');
const games = {
  impostor: { title: 'O Impostor', description: 'Descubra quem não sabe a palavra.', tag: 'Blefe & pistas', number: '01' },
  thought: { title: 'Mesmo Pensamento', description: 'Tente pensar igual aos seus amigos.', tag: 'Sintonia & opinião', number: '02' },
  timer: { title: 'Tempo Cego', description: 'Confie na sua noção de tempo.', tag: 'Instinto & precisão', number: '03' },
  taboo: { title: 'Dica Proibida', description: 'Faça seu parceiro acertar sem dizer o óbvio.', tag: 'Duplas & palavras', number: '04' },
};
const defaults = {
  schema: 1, players: [],
  settings: { impostor: { categories: [], impostors: 1 }, thought: { categories: [], target: 10 }, taboo: { teamA: ['Dupla A 1', 'Dupla A 2'], teamB: ['Dupla B 1', 'Dupla B 2'], duration: 60, rounds: 4 }, vibration: true, tapReveal: false },
  history: { words: { used: [], recent: [] }, questions: { used: [], recent: [] } }, recentTargets: [], session: null,
};
let state = sanitize(await loadState(defaults));
let route = '/';
let playersReturn = '/';
let installAvailable = false;
let offlineReady = false;
let storageWarning = false;
let lockedUntil = 0;
let lastAction = '';
let hold = null;
let holdTimeout = 0;
let timerFrame = 0;
let timerHideTimeout = 0;
let timerStart = null;
let timerReadyAt = 0;
let toastTimeout = 0;

function sanitize(saved) {
  const s = structuredClone(defaults);
  if (!saved || saved.schema !== 1) return s;
  if (Array.isArray(saved.players)) {
    const seen = new Set();
    s.players = saved.players.filter(p => p && typeof p.id === 'string' && typeof p.name === 'string' && p.name.trim() && !seen.has(normalizeText(p.name)) && seen.add(normalizeText(p.name))).slice(0, 7).map(p => ({ id: p.id, name: p.name.trim().slice(0, 24) }));
  }
  for (const kind of ['impostor', 'thought']) {
    const categories = kind === 'impostor' ? WORD_CATEGORIES : QUESTION_CATEGORIES;
    s.settings[kind] = { ...s.settings[kind], ...saved.settings?.[kind] };
    s.settings[kind].categories = Array.isArray(s.settings[kind].categories) ? [...new Set(s.settings[kind].categories.filter(id => categories.some(c => c.id === id)))] : [];
  }
  s.settings.impostor.impostors = Math.max(1, Math.min(Number(s.settings.impostor.impostors) || 1, Math.max(1, s.players.length - 2)));
  if (![10, 20, 30].includes(s.settings.thought.target)) s.settings.thought.target = 10;
  s.settings.taboo = { ...s.settings.taboo, ...saved.settings?.taboo };
  for (const team of ['teamA', 'teamB']) s.settings.taboo[team] = Array.isArray(s.settings.taboo[team]) ? s.settings.taboo[team].slice(0, 2).map((n, i) => String(n || '').trim().slice(0, 24) || `Dupla ${team === 'teamA' ? 'A' : 'B'} ${i + 1}`) : [...defaults.settings.taboo[team]];
  if (![60, 75, 90].includes(Number(s.settings.taboo.duration))) s.settings.taboo.duration = 60;
  if (![4, 6, 8, 10, 12].includes(Number(s.settings.taboo.rounds))) s.settings.taboo.rounds = 4;
  for (const key of ['vibration', 'tapReveal']) if (typeof saved.settings?.[key] === 'boolean') s.settings[key] = saved.settings[key];
  for (const bank of ['words', 'questions']) {
    const h = saved.history?.[bank];
    if (h && Array.isArray(h.used) && Array.isArray(h.recent)) s.history[bank] = h;
  }
  s.recentTargets = Array.isArray(saved.recentTargets) ? saved.recentTargets.filter(n => Number.isInteger(n) && n >= 200 && n <= 1500).slice(-5) : [];
  const a = saved.session;
  // Sessions contain player snapshots; editing the lobby cannot change a saved round.
  const phases = { impostor: ['pass', 'reveal', 'discussion', 'result'], thought: ['pass', 'answer', 'result'], timer: ['ready', 'running', 'result'], taboo: ['playing', 'handoff', 'result'] };
  if (a && phases[a.kind]?.includes(a.phase) && (a.kind === 'taboo' ? Array.isArray(a.players) && a.players.length === 4 && Number.isInteger(a.turnIndex) : Array.isArray(a.players) && a.players.length >= 3 && a.players.length <= 7 && a.players.every(p => typeof p.id === 'string' && typeof p.name === 'string') && Number.isInteger(a.index))) {
    const valid = a.kind === 'impostor' ? a.item?.word && a.item?.hint && Array.isArray(a.impostorIds) && a.settings : a.kind === 'thought' ? a.question?.text && Array.isArray(a.answers) && a.scores && Array.isArray(a.groups) && Array.isArray(a.winners) && a.settings : a.kind === 'timer' ? Array.isArray(a.order) && a.order.length > 0 && Array.isArray(a.results) && Array.isArray(a.winners) && Number.isInteger(a.targetCs) : Array.isArray(a.players) && a.players.length === 4 && a.settings && a.card?.word && Array.isArray(a.usedCardIds) && a.teamScores && a.playerScores && Number.isInteger(a.turnIndex) && Number.isFinite(a.turnStartedAt);
    if (valid) {
      s.session = a;
      if (a.kind === 'impostor' && a.phase === 'reveal') a.phase = 'pass';
      if (a.kind === 'thought' && a.phase === 'answer') a.phase = 'pass';
      if (a.kind === 'timer' && a.phase === 'running') interruptTimer(a);
    }
  }
  return s;
}

const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
const nameOf = (id, players = state.session?.players || state.players) => players.find(p => p.id === id)?.name || 'Jogador';
const initials = name => [...name.trim()][0]?.toLocaleUpperCase('pt-BR') || '?';
const button = (text, action, { secondary = false, symbol = '', data = '', disabled = false, accent = false } = {}) => `<button class="btn${secondary ? ' secondary' : ''}${accent ? ' accent' : ''}" data-action="${action}" ${data} ${disabled ? 'disabled' : ''}>${symbol ? icon(symbol) : ''}${text}</button>`;
const iconButton = (symbol, label, action, data = '', disabled = false) => `<button class="icon-button" aria-label="${esc(label)}" data-action="${action}" ${data} ${disabled ? 'disabled' : ''}>${icon(symbol)}</button>`;

function persist() {
  saveState(state).then(ok => {
    if (!ok && !storageWarning) { storageWarning = true; toast('O aparelho não permitiu salvar. Mantenha o app aberto nesta partida.'); }
  });
}
function buzz() { if (state.settings.vibration && navigator.vibrate) navigator.vibrate(12); }
function toast(message) {
  const el = document.querySelector('#toast');
  el.textContent = message; el.classList.add('visible');
  clearTimeout(toastTimeout); toastTimeout = setTimeout(() => el.classList.remove('visible'), 3400);
}
function confirmAction(title, message, label, callback, danger = false) {
  if (modal.open) return;
  conceal();
  if (state.session?.kind === 'thought' && state.session.phase === 'answer') { state.session.phase = 'pass'; persist(); render(false); }
  modal.innerHTML = `<h2 id="modal-title">${esc(title)}</h2><p>${esc(message)}</p><div class="actions"><button class="btn ${danger ? 'danger' : ''}" id="modal-confirm">${esc(label)}</button><button class="btn secondary" id="modal-cancel" autofocus>Cancelar</button></div>`;
  modal.querySelector('#modal-confirm').onclick = () => { modal.close(); lockedUntil = performance.now() + 250; callback(); };
  modal.querySelector('#modal-cancel').onclick = () => modal.close();
  modal.showModal();
}
function header(title = '', trailing = '') {
  return `<header class="topbar">${iconButton('back', 'Voltar', 'back')}<span class="label">${esc(title)}</span>${trailing}</header>`;
}
function navigate(next, replace = false) {
  conceal();
  if (state.session?.kind === 'thought' && state.session.phase === 'answer') state.session.phase = 'pass';
  if (next !== '/play') interruptCurrentTimer();
  persist(); stopAnimation(); route = next;
  history[replace ? 'replaceState' : 'pushState']({ route }, '', `#${route}`);
  render(); window.scrollTo(0, 0);
}
function isActive() { return state.session && (state.session.phase !== 'result' || (state.session.kind === 'thought' && !state.session.winners.length)); }
function leave(next = '/') {
  if (route === '/play' && isActive()) {
    confirmAction('Sair da partida?', 'A partida fica salva neste aparelho. Uma contagem em andamento será encerrada sem pontuar.', 'Sair e salvar', () => { conceal(); interruptCurrentTimer(); persist(); navigate(next); });
  } else {
    if (route === '/play' && state.session?.phase === 'result') { state.session = null; persist(); }
    navigate(next);
  }
}
function render(focus = true) {
  const kind = route.startsWith('/setup/') ? route.split('/')[2] : route === '/play' ? state.session?.kind : null;
  app.className = kind ? `${kind}-theme` : '';
  const content = route === '/players' ? playersView() : route === '/settings' ? settingsView() : route.startsWith('/setup/') && games[kind] ? setupView(kind) : route === '/play' && state.session ? playView() : homeView();
  app.innerHTML = `<div class="screen">${content}</div>`;
  document.title = kind ? `${games[kind].title} · MiniJogos` : 'MiniJogos';
  setAwake(route === '/play' && Boolean(isActive()));
  if (focus) app.querySelector('h1')?.focus({ preventScroll: true });
}

function homeView() {
  const s = state.session;
  return `<header class="topbar home-head"><span class="brand">MiniJogos<span class="brand-dot">.</span></span>${iconButton('settings', 'Configurações', 'settings')}</header>
    <div class="eyebrow">Jogos rápidos. Um celular.</div><h1 class="home-intro" tabindex="-1">Junte a turma.<br>O jogo começa aqui.</h1>
    ${s ? `<section class="resume"><strong>Tem jogo esperando vocês.</strong><p>${esc(games[s.kind].title)} · ${s.players.length} jogadores</p>${button('Continuar partida', 'resume', { symbol: 'arrow' })}</section>` : ''}
    <div class="game-list">${Object.entries(games).map(([id, g]) => `<button class="game-card ${id}" data-action="setup" data-game="${id}"><div class="game-copy"><span class="game-number">${g.number} / ${g.tag}</span><h2>${g.title}</h2><p>${g.description}</p></div><span class="game-symbol">${icon(id)}</span>${icon('arrow')}</button>`).join('')}</div>
    <button class="player-shortcut" data-action="players"><span class="avatars">${state.players.length ? state.players.slice(0, 3).map(p => `<span class="avatar">${esc(initials(p.name))}</span>`).join('') : icon('people')}</span>${state.players.length ? `${state.players.length} jogadores na turma` : 'Monte sua turma'}${icon('arrow')}</button>
    <div class="home-footer">${icon('lock')}<span>Sem conta. Só vocês.</span></div>`;
}
function setupView(kind) {
  if (kind === 'taboo') return tabooSetupView();
  const game = games[kind];
  const count = state.players.length;
  const categories = kind === 'impostor' ? WORD_CATEGORIES : QUESTION_CATEGORIES;
  const selection = state.settings[kind]?.categories || [];
  return `${header(game.title)}<div class="game-heading"><span class="game-badge">${icon(kind)}${game.tag}</span><h1 tabindex="-1">${kind === 'impostor' ? 'Quem está<br>blefando?' : kind === 'thought' ? 'Na mesma<br>frequência.' : 'Conte com<br>o seu instinto.'}</h1><p class="body-copy">${kind === 'impostor' ? 'Uma palavra. Uma dica. Alguém vai precisar improvisar.' : kind === 'thought' ? 'A mesma pergunta para todos. Respostas iguais valem pontos.' : 'O tempo some em 0,30 segundo. Pare quando achar que chegou ao alvo.'}</p></div>
    <section class="section"><div class="section-title"><h2>A turma <span class="muted">${count}/7</span></h2><button class="text-button" data-action="players">${icon('edit')}Editar</button></div>${count ? `<div class="player-pills">${state.players.map(p => `<span class="pill">${esc(p.name)}</span>`).join('')}</div>${count < 3 ? '<p class="helper">Faltam jogadores. Chamem pelo menos 3 pessoas.</p>' : ''}` : `<div class="empty-players">Adicione de 3 a 7 jogadores para começar.${button('Adicionar jogadores', 'players', { symbol: 'plus' })}</div>`}</section>
    ${kind === 'impostor' ? `<section class="section"><div class="section-title"><h2>Impostores</h2><span class="small muted">Pelo menos 2 pessoas sabem a palavra</span></div><div class="stepper">${iconButton('minus', 'Diminuir impostores', 'impostors', 'data-delta="-1"', state.settings.impostor.impostors <= 1)}<strong>${state.settings.impostor.impostors}</strong>${iconButton('plus', 'Aumentar impostores', 'impostors', 'data-delta="1"', state.settings.impostor.impostors >= Math.max(1, count - 2))}</div></section>` : ''}
    ${kind === 'thought' ? `<section class="section"><div class="section-title"><h2>Pontos para vencer</h2></div><div class="segmented">${[10, 20, 30].map(n => `<button class="chip" data-action="target" data-target="${n}" aria-pressed="${state.settings.thought.target === n}">${n}</button>`).join('')}</div><p class="helper">2 ou mais respostas equivalentes: +1 para cada pessoa. Sem par: 0. Empates na liderança são compartilhados.</p></section>` : ''}
    ${kind !== 'timer' ? `<section class="section"><div class="section-title"><h2>${kind === 'impostor' ? 'Categorias de palavras' : 'Categorias de perguntas'}</h2></div><div class="chips"><button class="chip" data-action="category" data-category="all" data-game="${kind}" aria-pressed="${selection.length === 0}">Todas</button>${categories.map(c => `<button class="chip" data-action="category" data-category="${c.id}" data-game="${kind}" aria-pressed="${selection.includes(c.id)}">${c.label}</button>`).join('')}</div><p class="helper">Escolha uma ou várias. O conteúdo só se repete depois que as opções selecionadas acabarem.</p></section>` : `<section class="section"><div class="rule-line">${icon('timer')}<span>Alvo entre 02:00 e 15:00.<br><strong>Segundos : centésimos</strong></span></div><div class="rule-line">${icon('hand')}<span>Um toque inicia. O próximo para.<br>Sem voltar ou refazer a tentativa.</span></div><div class="rule-line">${icon('eye')}<span>Todos veem o alvo. Os resultados só aparecem no final.</span></div><p class="helper">Se o app sair de foco durante a contagem, a tentativa é encerrada sem pontuar.</p></section>`}
    <div class="sticky-action">${button('Vamos jogar', 'start', { symbol: 'arrow', data: `data-game="${kind}"`, disabled: count < 3 || count > 7, accent: true })}</div>`;
}
function playersView() {
  return `${header('A turma')}<h1 tabindex="-1">Todo mundo<br>nessa?</h1><p class="body-copy">De 3 a 7 jogadores. Os nomes ficam salvos.</p><div class="section" id="player-list">${state.players.map((p, i) => `<div class="player-row"><span class="avatar">${i + 1}</span><input aria-label="Nome do jogador ${i + 1}" data-player="${esc(p.id)}" value="${esc(p.name)}" maxlength="24" autocomplete="off" spellcheck="false"><span class="reorder">${iconButton('up', `Mover ${p.name} para cima`, 'move-player', `data-player="${p.id}" data-delta="-1"`, i === 0)}${iconButton('down', `Mover ${p.name} para baixo`, 'move-player', `data-player="${p.id}" data-delta="1"`, i === state.players.length - 1)}</span>${iconButton('close', `Remover ${p.name}`, 'remove-player', `data-player="${p.id}"`)}</div>`).join('')}</div>
    ${state.players.length < 7 ? `<form class="add-player" id="add-player"><input class="field" name="name" aria-label="Nome do novo jogador" placeholder="Nome de quem vai jogar" maxlength="24" autocomplete="off" required><button class="btn" aria-label="Adicionar jogador">${icon('plus')}</button></form>` : '<p class="helper">Turma completa: 7 jogadores.</p>'}<p id="player-error" class="error" role="alert"></p>
    <div class="actions">${button('Turma pronta', 'players-done', { symbol: 'check' })}</div><p class="helper center">Use as setas para organizar a ordem.</p>`;
}
function settingsView() {
  return `${header('Configurações')}<h1 tabindex="-1">Do seu jeito.</h1><section class="section"><label class="toggle-row"><span class="toggle-copy"><strong>Vibração</strong><p>Um toque de resposta nas ações, quando disponível.</p></span><input type="checkbox" data-setting="vibration" ${state.settings.vibration ? 'checked' : ''}></label><label class="toggle-row"><span class="toggle-copy"><strong>Revelar sem segurar</strong><p>Acessibilidade: no Impostor, um toque revela e outro esconde e passa.</p></span><input type="checkbox" data-setting="tapReveal" ${state.settings.tapReveal ? 'checked' : ''}></label></section>
    <section class="section"><div class="section-title"><h2>Pronto para sair do Wi-Fi</h2></div><div class="status-line">${icon(offlineReady ? 'check' : 'download')}<span>${offlineReady ? 'Os quatro jogos estão disponíveis offline neste aparelho.' : 'Conecte-se à internet e abra o app para preparar todos os jogos offline.'}</span></div>${button(installAvailable ? 'Instalar MiniJogos' : 'Como instalar', 'install', { secondary: true, symbol: 'download' })}</section>
    <section class="section"><div class="section-title"><h2>Sempre uma rodada diferente</h2></div><div class="settings-stat"><span>Cartas de Dica Proibida</span><strong>${TABOO_CARDS.length}</strong></div><div class="settings-stat"><span>Palavras no banco</span><strong>${WORDS.length}</strong></div><div class="settings-stat"><span>Perguntas no banco</span><strong>${QUESTIONS.length}</strong></div><div class="settings-stat"><span>Palavras já sorteadas</span><strong>${new Set(state.history.words.used).size}</strong></div><div class="settings-stat"><span>Perguntas já sorteadas</span><strong>${new Set(state.history.questions.used).size}</strong></div><button class="text-button" data-action="reset-history">${icon('replay')}Reiniciar histórico de conteúdo</button></section>
    <p class="small muted">Tudo fica neste aparelho. Sem login, servidor ou envio das respostas. Limpar os dados do navegador também apaga suas partidas.</p><p class="settings-version">MiniJogos · versão 1.1</p>`;
}

function progress(index, length) { return `<div class="progress" aria-label="Jogador ${Math.min(index + 1, length)} de ${length}">${Array.from({ length }, (_, i) => `<span class="${i < index ? 'done' : i === index ? 'now' : ''}"></span>`).join('')}</div>`; }
function playView() {
  const s = state.session;
  return `${header(games[s.kind].title)}${s.kind === 'impostor' ? impostorView(s) : s.kind === 'thought' ? thoughtView(s) : s.kind === 'timer' ? timerView(s) : tabooView(s)}`;
}
function roundTools(previous = false) {
  return `<div class="actions">${previous ? '<button class="text-button" data-action="previous-player">' + icon('back') + 'Voltar ao jogador anterior</button>' : ''}<button class="text-button" data-action="skip">${icon('skip')}Pular rodada</button></div>`;
}
function impostorView(s) {
  if (s.phase === 'pass' || s.phase === 'reveal') {
    const p = s.players[s.index];
    return `${progress(s.index, s.players.length)}<div class="turn-title"><p class="turn-label">Passe o celular para</p><h1 class="turn-name" tabindex="-1">${esc(p.name)}</h1></div>
      <button class="secret-card" id="secret-card" data-action="secret" aria-label="${state.settings.tapReveal ? 'Revelar carta' : 'Pressione e segure para revelar. Solte para esconder e passar.'}">${closedCard()}</button><p class="card-help">${state.settings.tapReveal ? 'Toque novamente para esconder e passar.' : 'Ao soltar, a carta fecha e passa para o próximo.'}</p><p class="privacy-line">${icon('lock')}Só você deve ver a tela.</p>${roundTools(s.index > 0)}`;
  }
  if (s.phase === 'discussion') return `<div class="discussion">${icon('impostor')}<div class="eyebrow" style="margin-top:24px">Todo mundo já viu</div><h1 tabindex="-1">${esc(nameOf(s.starterId))}<br>começa.</h1><p>Comecem as pistas e tentem encontrar o impostor.</p></div><div class="actions">${button('Revelar impostor', 'reveal-impostor', { symbol: 'eye', accent: true })}</div>${roundTools(true)}`;
  return `<div class="eyebrow">Mistério resolvido</div><h1 tabindex="-1">${s.impostorIds.length > 1 ? 'Eles estavam<br>blefando.' : 'Era você!'}</h1><div class="impostor-names">${s.impostorIds.map(id => esc(nameOf(id))).join(' · ')}</div><section class="round-result"><div class="eyebrow">A palavra era</div><div class="big-answer">${esc(s.item.word)}</div><div class="eyebrow">Dica do impostor</div><p>${esc(s.item.hint)}</p></section><div class="actions">${button('Nova rodada', 'new-round', { symbol: 'replay', accent: true })}${button('Voltar ao lobby', 'lobby', { secondary: true })}</div>`;
}
function closedCard() { return `${icon('hand')}<span class="secret-instruction">${state.settings.tapReveal ? 'Toque para revelar' : 'Pressione e segure<br>para revelar'}</span>`; }
function thoughtView(s) {
  if (s.phase === 'pass') {
    const p = s.players[s.index];
    return `${progress(s.index, s.players.length)}<div class="eyebrow center">Rodada ${s.round}</div><div class="handoff-symbol">${icon('thought')}</div><div class="turn-title"><p class="turn-label">Passe o celular para</p><h1 class="turn-name" tabindex="-1">${esc(p.name)}</h1></div><p class="center muted small">A pergunta aparece só na sua vez.</p><div class="actions">${button('Sou ' + esc(p.name), 'open-question', { symbol: 'arrow', accent: true })}</div><p class="privacy-line">${icon('lock')}Respostas secretas até todo mundo jogar.</p>${roundTools()}`;
  }
  if (s.phase === 'answer') return `<div class="turn-meta"><span>Vez de <strong>${esc(s.players[s.index].name)}</strong></span><span>Rodada ${s.round}</span></div><h1 class="question" tabindex="-1">${esc(s.question.text)}</h1><form id="answer-form" class="answer-form"><label class="answer-label" for="answer">Sua resposta</label><input class="field" id="answer" name="answer" maxlength="80" placeholder="Escreva sem mostrar aos outros" autocomplete="off" autocorrect="off" spellcheck="false" required value="${esc(s.draft || '')}"><p class="helper">${s.question.group ? 'Responda com um nome da turma. “Eu” também vale.' : 'Pode ser curta. Acentos, apelidos comuns e pequenos erros são comparados.'}</p><button class="btn accent">Pronto ${icon('check')}</button><p class="error" id="answer-error" role="alert"></p></form>${roundTools()}`;
  const winners = s.winners || [];
  return `<div class="eyebrow">Rodada ${s.round} · respostas reveladas</div><h1 tabindex="-1">${s.groups.some(g => g.points) ? 'Deu sintonia!' : 'Pensaram diferente.'}</h1>${winners.length ? `<div class="winner-banner">${icon('trophy')}<h2>${winners.map(id => esc(nameOf(id))).join(' & ')}</h2><p>${winners.length > 1 ? 'Empate! A vitória é de vocês.' : 'Venceu a partida!'} ${s.settings.target} pontos para vencer.</p></div>` : ''}<p class="body-copy small">${esc(s.question.text)}</p><section class="section">${s.groups.map(g => `<div class="answer-group"><div class="group-head"><h3>${esc(g.label)}</h3><span class="point-badge ${g.points ? '' : 'zero'}">${g.points ? '+1 cada' : 'Sem par · 0'}</span></div><div class="answer-people">${g.playerIds.map(id => `<span>${esc(nameOf(id))}</span>`).join('')}</div>${new Set(g.answers.map(a => a.text)).size > 1 ? `<div class="answer-originals">${g.answers.map(a => esc(a.text)).join(' / ')}</div>` : ''}</div>`).join('')}</section>
    <section class="scoreboard"><div class="section-title"><h2>Placar</h2><span class="small muted">Meta: ${s.settings.target}</span></div>${[...s.players].sort((a, b) => s.scores[b.id] - s.scores[a.id]).map((p, i) => `<div class="score-row"><span class="position">${i + 1}</span><span class="avatar">${esc(initials(p.name))}</span><span class="name">${esc(p.name)}</span><span class="score">${s.scores[p.id]}</span></div>`).join('')}</section><div class="actions">${button(winners.length ? 'Jogar novamente' : 'Próxima rodada', winners.length ? 'new-round' : 'next-question', { symbol: winners.length ? 'replay' : 'arrow', accent: true })}${button('Voltar ao lobby', 'lobby', { secondary: true })}</div>`;
}
function timerView(s) {
  const target = `<div class="target-box"><div class="eyebrow">Objetivo${s.tieRound ? ' · desempate' : ''}</div><div class="target-time">${formatTime(s.targetCs)}</div><div class="time-unit">segundos : centésimos</div></div>`;
  if (s.phase !== 'result') return `${progress(s.index, s.order.length)}${target}<div class="turn-title"><p class="turn-label">Vez de</p><h1 class="turn-name" tabindex="-1">${esc(nameOf(s.order[s.index].id))}</h1></div><button class="timer-zone ${s.phase === 'running' ? 'running' : ''}" data-action="timer" id="timer-zone">${s.phase === 'running' ? '<span class="timer-digits" id="timer-digits" aria-hidden="true">00:00</span><span class="timer-instruction">Toque para parar</span>' : `${icon('timer')}<strong>Toque para começar</strong><p>O próximo toque para o tempo.</p>`}</button><p class="privacy-line">${icon('lock')}O resultado fica guardado até o final.</p>`;
  return `<div class="eyebrow">Todos jogaram</div><h1 tabindex="-1">${s.winners.length > 1 ? 'EMPATE' : s.winners.length ? 'No tempo certo.' : 'Rodada encerrada.'}</h1><div class="winner-banner">${icon('trophy')}<h2>${s.winners.length ? s.winners.map(id => esc(nameOf(id))).join(' & ') : 'Vamos de novo?'}</h2><p>${s.winners.length > 1 ? 'Exatamente a mesma distância do alvo.' : s.winners.length ? 'Chegou mais perto do alvo e venceu.' : 'As tentativas foram interrompidas.'}</p></div>${target}<table class="timer-table"><thead><tr><th>Jogador</th><th>Tempo</th><th>Diferença</th></tr></thead><tbody>${ranking(s).map(r => `<tr class="${s.winners.includes(r.playerId) ? 'winner' : ''}"><td>${esc(nameOf(r.playerId))}</td><td>${r.interrupted ? 'Interrompido' : formatTime(r.centiseconds)}</td><td>${r.interrupted ? '—' : formatTime(r.difference)}</td></tr>`).join('')}</tbody></table><div class="actions">${s.winners.length > 1 ? button('Desempatar', 'tiebreak', { symbol: 'timer', accent: true }) : ''}${button('Jogar novamente', 'new-round', { symbol: 'replay', accent: s.winners.length <= 1, secondary: s.winners.length > 1 })}${button('Voltar ao lobby', 'lobby', { secondary: true })}</div>`;
}


function tabooSetupView() {
  const t = state.settings.taboo;
  const nameField = (team, member, label) => `<label class="taboo-name-field"><span>${label}</span><input class="field" data-taboo-name data-team="${team}" data-member="${member}" value="${esc(t[team][member])}" maxlength="24" autocomplete="off" required></label>`;
  return `${header('Dica Proibida')}<div class="game-heading"><span class="game-badge">${icon('taboo')}Duplas · palavras</span><h1 tabindex="-1">Diga tudo.<br>Menos o óbvio.</h1><p class="body-copy">Um jogador dá pistas para o parceiro acertar. Quatro palavras proibidas tornam tudo mais difícil.</p></div>
    <section class="section"><div class="section-title"><h2>Dupla A</h2><span class="small muted">2 jogadores</span></div><div class="taboo-team">${nameField('teamA',0,'Integrante 1')}${nameField('teamA',1,'Integrante 2')}</div></section>
    <section class="section"><div class="section-title"><h2>Dupla B</h2><span class="small muted">2 jogadores</span></div><div class="taboo-team">${nameField('teamB',0,'Integrante 1')}${nameField('teamB',1,'Integrante 2')}</div></section>
    <section class="section"><div class="section-title"><h2>Tempo por turno</h2></div><div class="segmented">${[60,75,90].map(n=>`<button class="chip" data-action="taboo-duration" data-value="${n}" aria-pressed="${t.duration===n}">${n}s</button>`).join('')}</div></section>
    <section class="section"><div class="section-title"><h2>Quantidade de rodadas</h2></div><div class="chips">${[4,6,8,10,12].map(n=>`<button class="chip" data-action="taboo-rounds" data-value="${n}" aria-pressed="${t.rounds===n}">${n}</button>`).join('')}</div><p class="helper">Cada rodada é um turno cronometrado. As duplas alternam e, na próxima vez de cada dupla, os integrantes trocam de função.</p></section>
    <section class="section"><div class="rule-line">${icon('shield')}<span>Acertou: +1 ponto para a dupla. Falou uma palavra proibida: +1 para a adversária.</span></div><div class="rule-line">${icon('lock')}<span>O placar fica escondido até o final. É possível desfazer a última marcação.</span></div></section>
    <div class="sticky-action">${button('Começar partida','start',{symbol:'arrow',data:'data-game="taboo"',accent:true})}</div>`;
}
function tabooPlayerName(s, team, member) { return s.players.find(p=>p.team===team && p.member===member)?.name || 'Jogador'; }
function tabooTurn(s) {
  const team = s.turnIndex % 2 === 0 ? 'A' : 'B';
  const occurrence = Math.floor(s.turnIndex / 2);
  const clueMember = occurrence % 2;
  const guessMember = 1 - clueMember;
  const clueId = `team${team}`;
  const guessId = clueId;
  return { team, clueMember, guessMember, clue: s.players.find(p=>p.team===team && p.member===clueMember), guess: s.players.find(p=>p.team===guessId && p.member===guessMember) };
}
function makeTabooCard(used=[]) {
  const pool = TABOO_CARDS.filter(c=>!used.includes(c.id));
  const source = pool.length ? pool : TABOO_CARDS;
  return source[Math.floor(Math.random()*source.length)];
}
function startTaboo() {
  const t = state.settings.taboo;
  for (const field of document.querySelectorAll('[data-taboo-name]')) t[field.dataset.team][Number(field.dataset.member)] = field.value.trim().replace(/\s+/g,' ').slice(0,24);
  const names = [...t.teamA, ...t.teamB].map(n=>String(n||'').trim());
  if (names.some(n=>!n)) { toast('Preencha os nomes dos quatro jogadores.'); return; }
  if (new Set(names.map(normalizeText)).size !== 4) { toast('Cada jogador precisa de um nome diferente.'); return; }
  const players = [
    {id:crypto.randomUUID(), name:names[0], team:'teamA', member:0}, {id:crypto.randomUUID(), name:names[1], team:'teamA', member:1},
    {id:crypto.randomUUID(), name:names[2], team:'teamB', member:0}, {id:crypto.randomUUID(), name:names[3], team:'teamB', member:1},
  ];
  state.session = {kind:'taboo', phase:'playing', players, settings:{...t, teamA:[...t.teamA],teamB:[...t.teamB]}, turnIndex:0, totalRounds:t.rounds,
    turnStartedAt:Date.now(), card:makeTabooCard(), usedCardIds:[], teamScores:{teamA:0,teamB:0}, playerScores:Object.fromEntries(players.map(p=>[p.id,0])), lastAction:null, lastActionMessage:'', correctCount:0};
  state.session.usedCardIds.push(state.session.card.id); persist(); navigate('/play'); startTabooClock();
}
function startTabooClock() {
  cancelAnimationFrame(timerFrame); timerFrame=0;
  const s=state.session;
  if (route!=='/play' || s?.kind!=='taboo' || s.phase!=='playing') return;
  const tick=()=>{
    if (route!=='/play' || state.session!==s || s.phase!=='playing') { timerFrame=0; return; }
    const remaining=Math.max(0,s.settings.duration*1000-(Date.now()-s.turnStartedAt));
    const el=document.querySelector('#taboo-countdown'); if(el) el.textContent=formatCountdown(remaining);
    if(remaining<=0){timerFrame=0; finishTabooTurn(); return;}
    timerFrame=requestAnimationFrame(tick);
  };
  timerFrame=requestAnimationFrame(tick);
}
function formatCountdown(ms) { const sec=Math.ceil(ms/1000); return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`; }
function tabooMark(type) {
  const s=state.session; if(!s || s.kind!=='taboo'||s.phase!=='playing')return;
  if (Date.now()-s.turnStartedAt >= s.settings.duration*1000) { finishTabooTurn(); return; }
  const turn=tabooTurn(s);
  s.lastAction={card:s.card,usedCardIds:[...s.usedCardIds],teamScores:{...s.teamScores},playerScores:{...s.playerScores},correctCount:s.correctCount,turnStartedAt:s.turnStartedAt};
  if(type==='correct') { s.teamScores[turn.clue.team]++; s.playerScores[turn.clue.id]++; s.correctCount++; s.lastActionMessage=`Ponto de ${turn.clue.name}`; }
  else { const other=turn.team==='A'?'teamB':'teamA'; s.teamScores[other]++; const nextTeam=turn.team==='A'?'B':'A'; const nextMember=Math.floor(s.turnIndex/2)%2; const beneficiary=s.players.find(p=>p.team===`team${nextTeam}`&&p.member===nextMember); if(beneficiary) s.playerScores[beneficiary.id]++; s.lastActionMessage='Ponto para a dupla adversária'; }
  s.card=makeTabooCard(s.usedCardIds); s.usedCardIds.push(s.card.id); persist(); buzz(); render(false); startTabooClock();
}
function tabooUndo() {
  const s=state.session; if(!s?.lastAction)return;
  if (Date.now()-s.turnStartedAt >= s.settings.duration*1000) { finishTabooTurn(); return; }
  const a=s.lastAction; s.card=a.card; s.usedCardIds=[...a.usedCardIds]; s.teamScores={...a.teamScores}; s.playerScores={...a.playerScores}; s.correctCount=a.correctCount; s.turnStartedAt=a.turnStartedAt; s.lastAction=null; s.lastActionMessage=''; persist(); render(false); startTabooClock(); toast('Última marcação desfeita.');
}
function finishTabooTurn() {
  const s=state.session; if(!s||s.kind!=='taboo'||s.phase!=='playing')return;
  cancelAnimationFrame(timerFrame); timerFrame=0; s.phase='handoff'; s.lastAction=null; persist(); render(); buzz();
}
function tabooNextTurn() {
  const s=state.session; if(!s||s.kind!=='taboo'||s.phase!=='handoff')return;
  if(s.turnIndex+1>=s.totalRounds) { s.phase='result'; persist(); advanceView(); return; }
  s.turnIndex++; s.phase='playing'; s.turnStartedAt=Date.now(); s.card=makeTabooCard(s.usedCardIds); s.usedCardIds.push(s.card.id); s.lastAction=null; s.lastActionMessage=''; s.correctCount=0; persist(); advanceView(); startTabooClock();
}
function tabooView(s) {
  const turn=tabooTurn(s); const a=turn.team==='A'; const teamName=a?'Dupla A':'Dupla B';
  if(s.phase==='result') {
    const scoreA=s.teamScores.teamA, scoreB=s.teamScores.teamB; const winners=scoreA===scoreB?[]:[scoreA>scoreB?'teamA':'teamB'];
    return `<div class="eyebrow">Partida concluída · ${s.totalRounds} rodadas</div><h1 tabindex="-1">${winners.length?`${winners[0]==='teamA'?'Dupla A':'Dupla B'} venceu.`:'Deu empate.'}</h1><section class="winner-banner">${icon('trophy')}<h2>${scoreA===scoreB?'Empate':scoreA>scoreB?esc(s.settings.teamA.join(' & ')):esc(s.settings.teamB.join(' & '))}</h2><p>Placar final</p><div class="taboo-final-score"><div><span>Dupla A</span><strong>${scoreA}</strong></div><div><span>Dupla B</span><strong>${scoreB}</strong></div></div></section><section class="section"><div class="section-title"><h2>Pontos individuais</h2></div>${s.players.map(p=>`<div class="score-row"><span class="avatar">${esc(initials(p.name))}</span><span class="name">${esc(p.name)} <small class="muted">· ${p.team==='teamA'?'Dupla A':'Dupla B'}</small></span><span class="score">${s.playerScores[p.id]||0}</span></div>`).join('')}<p class="helper">Pontos individuais mostram quem contribuiu diretamente para os pontos marcados durante os turnos. Penalidades concedidas à dupla adversária também entram na pontuação individual do próximo integrante escalado.</p></section><div class="actions">${button('Jogar novamente','new-round',{symbol:'replay',accent:true})}${button('Voltar ao menu','lobby',{secondary:true})}</div>`;
  }
  if(s.phase==='handoff') {
    const nextIndex=s.turnIndex+1; const nextTeam=nextIndex%2===0?'A':'B'; const nextOccurrence=Math.floor(nextIndex/2); const nextMember=nextOccurrence%2; const nextPlayer=s.players.find(p=>p.team===`team${nextTeam}`&&p.member===nextMember);
    const final=s.turnIndex+1>=s.totalRounds;
    return `<div class="eyebrow">Turno ${s.turnIndex+1} de ${s.totalRounds}</div><h1 tabindex="-1">Tempo encerrado.</h1><div class="handoff-symbol">${icon('people')}</div><p class="body-copy center">${final?'Todas as rodadas terminaram. O placar será revelado.':`Passe o celular. Agora é a vez de ${esc(nextPlayer?.name||'o próximo jogador')} (${nextTeam==='A'?'Dupla A':'Dupla B'}).`}</p><div class="actions">${button(final?'Ver resultado final':'Passar para a próxima rodada','taboo-next',{symbol:'arrow',accent:true})}${button('Encerrar e revelar placar','taboo-end',{secondary:true})}</div>`;
  }
  return `<div class="progress" aria-label="Turno ${s.turnIndex+1} de ${s.totalRounds}">${Array.from({length:s.totalRounds},(_,i)=>`<span class="${i<s.turnIndex?'done':i===s.turnIndex?'now':''}"></span>`).join('')}</div><div class="turn-meta"><span>${teamName} · Turno ${s.turnIndex+1}/${s.totalRounds}</span><strong id="taboo-countdown">${formatCountdown(Math.max(0,s.settings.duration*1000-(Date.now()-s.turnStartedAt)))}</strong></div><div class="taboo-turn-card"><div class="eyebrow">Quem dá as dicas</div><h2>${esc(turn.clue.name)}</h2><p>Ajude ${esc(turn.guess.name)} a adivinhar sem dizer nenhuma palavra proibida.</p></div><section class="taboo-word-card"><div class="eyebrow">Palavra secreta</div><h1>${esc(s.card.word)}</h1><div class="forbidden-title">${icon('shield')}Palavras proibidas</div><div class="forbidden-list">${s.card.forbidden.map(w=>`<span>${esc(w)}</span>`).join('')}</div></section><div class="actions taboo-actions">${button('Acertamos! Próxima palavra','taboo-correct',{symbol:'check',accent:true})}${button('Errei / Falei palavra proibida','taboo-error',{secondary:true})}${s.lastAction?button('Desfazer última marcação','taboo-undo',{symbol:'replay',secondary:true}):''}${button('Encerrar e revelar placar','taboo-end',{secondary:true})}</div><p class="privacy-line">${icon('lock')}O placar continua oculto.</p>`;
}

function startGame(kind, players = state.players, settings = state.settings[kind]) {
  if (kind === 'impostor') state.session = createImpostor(players, settings, state.history.words);
  if (kind === 'thought') state.session = createThought(players, settings, state.history.questions);
  if (kind === 'timer') state.session = createTimer(players, state.recentTargets);
  buzz(); persist(); navigate('/play');
}
function advanceView() { persist(); render(); window.scrollTo(0, 0); }
function clampImpostors() { state.settings.impostor.impostors = Math.max(1, Math.min(state.settings.impostor.impostors, state.players.length - 2)); }
function playerError(message) { const el = document.querySelector('#player-error'); if (el) el.textContent = message; }
function validateName(name, exceptId) {
  if (!normalizeText(name)) return 'Digite um nome válido.';
  if (name.length > 24) return 'Use um nome com até 24 caracteres.';
  if (state.players.some(p => p.id !== exceptId && normalizeText(p.name) === normalizeText(name))) return 'Esse nome já está na turma. Use um sobrenome ou apelido diferente.';
  return '';
}
function newRound() {
  const s = state.session;
  if (!s || s.phase !== 'result') return;
  if (s.kind === 'taboo') { state.settings.taboo = {...s.settings, teamA:[...s.settings.teamA], teamB:[...s.settings.teamB]}; startTaboo(); return; }
  startGame(s.kind, s.players, s.settings);
}

app.addEventListener('click', async event => {
  const control = event.target.closest('[data-action]');
  if (!control || control.disabled || modal.open) return;
  const action = control.dataset.action;
  if (action === 'timer') { if (event.detail === 0) timerTap(); return; }
  if (action === 'secret') {
    // Assistive-technology activation uses click without a physical pointer.
    if (state.settings.tapReveal || (event.detail === 0 && (hold === null || hold === 'tap'))) {
      if (state.session?.phase === 'reveal') finishHold(); else revealCard('tap');
    }
    return;
  }
  if (performance.now() < lockedUntil && (action === lastAction || ['taboo-correct','taboo-error','taboo-undo','taboo-next'].includes(action))) return;
  lastAction = action;
  lockedUntil = performance.now() + 220;
  const s = state.session;
  try {
    switch (action) {
      case 'settings': navigate('/settings'); break;
      case 'setup': navigate(`/setup/${control.dataset.game}`); break;
      case 'players': playersReturn = route; navigate('/players'); break;
      case 'players-done': navigate(playersReturn); break;
      case 'back':
        if (route === '/players') navigate(playersReturn);
        else if (route === '/play') leave(`/setup/${s.kind}`);
        else navigate('/');
        break;
      case 'resume':
        if (!s) break;
        if (s.kind === 'thought' && s.phase === 'answer') s.phase = 'pass';
        if (s.kind === 'impostor' && s.phase === 'reveal') s.phase = 'pass';
        if (s.kind === 'timer' && s.phase === 'running') interruptTimer(s);
        persist(); navigate('/play'); if (s.kind === 'taboo' && s.phase === 'playing') startTabooClock(); break;
      case 'impostors':
        state.settings.impostor.impostors += Number(control.dataset.delta); clampImpostors(); persist(); render(false); break;
      case 'category': {
        const setting = state.settings[control.dataset.game];
        const id = control.dataset.category;
        setting.categories = id === 'all' ? [] : setting.categories.includes(id) ? setting.categories.filter(c => c !== id) : [...setting.categories, id];
        persist(); render(false); break;
      }
      case 'target': state.settings.thought.target = Number(control.dataset.target); persist(); render(false); break;
      case 'move-player': {
        const from = state.players.findIndex(p => p.id === control.dataset.player);
        const to = from + Number(control.dataset.delta);
        if (from >= 0 && to >= 0 && to < state.players.length) {
          [state.players[from], state.players[to]] = [state.players[to], state.players[from]];
          persist(); render(false);
        }
        break;
      }
      case 'remove-player': state.players = state.players.filter(p => p.id !== control.dataset.player); clampImpostors(); persist(); render(false); break;
      case 'start':
        if (control.dataset.game === 'taboo') { if (s && isActive()) confirmAction('Começar outra partida?', 'A partida salva será substituída.', 'Começar nova partida', () => startTaboo()); else startTaboo(); break; }
        if (s && isActive()) confirmAction('Começar outra partida?', 'A partida salva será substituída. Jogadores e histórico de conteúdo continuam salvos.', 'Começar nova partida', () => startGame(control.dataset.game));
        else startGame(control.dataset.game);
        break;
      case 'taboo-duration': state.settings.taboo.duration = Number(control.dataset.value); persist(); render(false); break;
      case 'taboo-rounds': state.settings.taboo.rounds = Number(control.dataset.value); persist(); render(false); break;
      case 'taboo-correct': if (s?.kind === 'taboo' && s.phase === 'playing') tabooMark('correct'); break;
      case 'taboo-error': if (s?.kind === 'taboo' && s.phase === 'playing') tabooMark('error'); break;
      case 'taboo-undo': if (s?.kind === 'taboo' && s.phase === 'playing') tabooUndo(); break;
      case 'taboo-next': if (s?.kind === 'taboo' && s.phase === 'handoff') tabooNextTurn(); break;
      case 'taboo-end': if (s?.kind === 'taboo') confirmAction('Encerrar a partida?', 'O placar será revelado agora e as rodadas restantes serão canceladas.', 'Encerrar e revelar', () => { s.phase = 'result'; persist(); advanceView(); }, true); break;
      case 'previous-player':
        if (s?.kind !== 'impostor' || s.index < 1) break;
        confirmAction('Voltar ao jogador anterior?', `Entregue o celular a ${s.players[s.index - 1].name}. A carta ficará fechada até essa pessoa revelar.`, 'Voltar jogador', () => { backImpostor(s); advanceView(); }); break;
      case 'reveal-impostor':
        if (s?.kind !== 'impostor' || s.phase !== 'discussion') break;
        confirmAction('Tem certeza que deseja revelar?', 'A palavra e os impostores serão mostrados para todos.', 'Revelar impostor', () => { revealImpostorResult(s); buzz(); advanceView(); }); break;
      case 'skip':
        if (!s || s.kind === 'timer' || s.phase === 'result') break;
        confirmAction('Tem certeza que deseja pular esta rodada?', s.kind === 'thought' ? 'A pergunta conta como utilizada. As respostas desta rodada serão descartadas e o placar permanece igual.' : 'A palavra conta como utilizada. Vamos sortear outra palavra, os impostores e quem começa.', 'Pular rodada', () => {
          conceal();
          state.session = s.kind === 'impostor' ? createImpostor(s.players, s.settings, state.history.words) : nextThought(s, state.history.questions);
          advanceView();
        }); break;
      case 'open-question': if (s?.kind === 'thought' && openThought(s)) advanceView(); break;
      case 'next-question':
        if (s?.kind === 'thought' && s.phase === 'result' && !s.winners.length) { state.session = nextThought(s, state.history.questions); advanceView(); }
        break;
      case 'new-round': newRound(); break;
      case 'lobby': if (s) leave(`/setup/${s.kind}`); break;
      case 'tiebreak':
        if (s?.kind === 'timer' && s.phase === 'result' && s.winners.length > 1) {
          state.session = createTimer(s.players, state.recentTargets, s.winners);
          state.session.tieRound = (s.tieRound || 0) + 1;
          advanceView();
        }
        break;
      case 'reset-history':
        confirmAction('Recomeçar o banco de conteúdo?', 'Palavras e perguntas já usadas poderão aparecer novamente. A partida salva e os jogadores continuam iguais.', 'Reiniciar histórico', () => { state.history = structuredClone(defaults.history); persist(); render(); toast('Histórico reiniciado.'); }); break;
      case 'install': {
        const result = await installApp();
        if (result === 'unavailable') {
          modal.innerHTML = `<h2 id="modal-title">MiniJogos na tela inicial</h2><p>No Android, abra o menu do navegador e escolha “Instalar app” ou “Adicionar à tela inicial”. No iPhone, use Compartilhar → Adicionar à Tela de Início.</p><div class="actions"><button class="btn" id="install-close">Entendi</button></div>`;
          modal.querySelector('button').onclick = () => modal.close(); modal.showModal();
        }
        break;
      }
    }
  } catch (error) { toast(error.message || 'Não foi possível concluir. Tente novamente.'); }
});

app.addEventListener('submit', event => {
  event.preventDefault();
  if (modal.open) return;
  if (event.target.id === 'add-player') {
    const field = event.target.elements.name;
    const name = field.value.trim().replace(/\s+/g, ' ');
    const error = validateName(name);
    if (error) { playerError(error); return; }
    if (state.players.length >= 7) return;
    state.players.push({ id: crypto.randomUUID(), name });
    persist(); render(false); document.querySelector('#add-player input')?.focus();
  }
  if (event.target.id === 'answer-form') {
    const s = state.session;
    if (!s || s.kind !== 'thought' || s.phase !== 'answer') return;
    const answer = event.target.elements.answer.value;
    if (!submitThought(s, answer, s.players[s.index].id)) { document.querySelector('#answer-error').textContent = 'Escreva uma resposta com até 80 caracteres.'; return; }
    delete s.draft; lockedUntil = performance.now() + 280;
    // Blur before removing the input so the shared phone keyboard also closes.
    document.activeElement?.blur(); buzz(); advanceView();
  }
});
app.addEventListener('change', event => {
  const input = event.target;
  if (input.hasAttribute('data-taboo-name')) { const team=input.dataset.team; const member=Number(input.dataset.member); const name=input.value.trim().replace(/\s+/g,' ').slice(0,24); state.settings.taboo[team][member]=name; input.value=name; persist(); }
  if (input.dataset.setting) { state.settings[input.dataset.setting] = input.checked; persist(); }
  if (input.dataset.player) {
    const player = state.players.find(p => p.id === input.dataset.player);
    if (!player) return;
    const name = input.value.trim().replace(/\s+/g, ' ');
    const error = validateName(name, player.id);
    if (error) { input.value = player.name; playerError(error); return; }
    player.name = name; input.value = name; playerError(''); persist();
  }
});
app.addEventListener('input', event => {
  if (event.target.id === 'answer' && state.session?.kind === 'thought' && state.session.phase === 'answer') {
    state.session.draft = event.target.value; persist();
  }
});

function revealCard(source) {
  const s = state.session;
  if (route !== '/play' || modal.open || s?.kind !== 'impostor' || s.phase !== 'pass') return;
  const card = document.querySelector('#secret-card');
  if (!card || !openImpostor(s)) return;
  hold = source;
  const spy = s.impostorIds.includes(s.players[s.index].id);
  card.classList.add('revealed'); card.classList.toggle('spy', spy);
  card.innerHTML = `<span class="secret-role">${spy ? 'IMPOSTOR' : 'SUA PALAVRA'}</span><span class="secret-word">${esc(spy ? s.item.hint : s.item.word)}</span><span class="secret-instruction">${spy ? 'Essa é sua dica. Entre na conversa.' : 'Guarde a palavra. Não entregue o jogo.'}</span>`;
  card.setAttribute('aria-label', `${spy ? 'Impostor. Dica: ' : 'Sua palavra: '}${spy ? s.item.hint : s.item.word}. ${state.settings.tapReveal || source === 'tap' ? 'Toque para esconder e passar.' : 'Solte para esconder e passar.'}`);
  persist(); buzz();
}
function conceal() {
  clearTimeout(holdTimeout); holdTimeout = 0; hold = null;
  const s = state.session;
  const card = document.querySelector('#secret-card');
  if (card) { card.classList.remove('revealed', 'spy'); card.innerHTML = closedCard(); card.setAttribute('aria-label', 'Carta fechada'); }
  if (s?.kind === 'impostor' && s.phase === 'reveal') { s.phase = 'pass'; persist(); }
}
function finishHold() {
  clearTimeout(holdTimeout); holdTimeout = 0;
  const s = state.session;
  if (s?.kind !== 'impostor' || s.phase !== 'reveal') { hold = null; return; }
  // Remove the actual secret synchronously before any screen animation.
  const card = document.querySelector('#secret-card');
  if (card) { card.innerHTML = closedCard(); card.classList.remove('revealed', 'spy'); card.setAttribute('aria-label', 'Carta fechada'); }
  hold = null; finishImpostorReveal(s); lockedUntil = performance.now() + 250; advanceView();
}
app.addEventListener('pointerdown', event => {
  const card = event.target.closest('#secret-card');
  if (card && !state.settings.tapReveal) {
    if (!event.isPrimary || event.button !== 0 || hold !== null || modal.open) return;
    event.preventDefault(); card.focus({ preventScroll: true });
    hold = event.pointerId; card.setPointerCapture(event.pointerId);
    holdTimeout = setTimeout(() => { if (hold === event.pointerId) revealCard(event.pointerId); }, 180);
  }
  if (event.target.closest('#timer-zone') && event.isPrimary && event.button === 0) { event.preventDefault(); timerTap(); }
});
document.addEventListener('pointerup', event => { if (hold === event.pointerId) finishHold(); });
document.addEventListener('pointercancel', event => { if (hold === event.pointerId) finishHold(); });
app.addEventListener('contextmenu', event => { if (event.target.closest('#secret-card, #timer-zone')) event.preventDefault(); });
app.addEventListener('keydown', event => {
  if (event.target.id === 'secret-card' && !state.settings.tapReveal && [' ', 'Enter'].includes(event.key)) {
    event.preventDefault(); if (!event.repeat && !hold) revealCard('keyboard');
  }
});
document.addEventListener('keyup', event => {
  if (hold === 'keyboard' && [' ', 'Enter'].includes(event.key)) { event.preventDefault(); finishHold(); }
});

function stopAnimation() { cancelAnimationFrame(timerFrame); timerFrame = 0; clearTimeout(timerHideTimeout); timerHideTimeout = 0; }
function interruptCurrentTimer() {
  stopAnimation(); timerStart = null;
  if (state.session?.kind === 'timer' && state.session.phase === 'running') { interruptTimer(state.session); timerReadyAt = performance.now() + 280; }
}
function timerTap() {
  const now = performance.now();
  const s = state.session;
  if (modal.open || route !== '/play' || s?.kind !== 'timer') return;
  if (s.phase === 'running') {
    if (timerStart === null) { interruptCurrentTimer(); advanceView(); return; }
    const elapsed = now - timerStart;
    stopAnimation(); timerStart = null;
    if (recordTimer(s, elapsed, s.order[s.index].id)) { timerReadyAt = now + 280; buzz(); advanceView(); }
    return;
  }
  if (s.phase !== 'ready' || now < timerReadyAt || !startTimer(s)) return;
  timerStart = now; persist(); render(false);
  const digits = document.querySelector('#timer-digits');
  timerHideTimeout = setTimeout(() => { if (s.phase === 'running') { digits.textContent = ''; digits.classList.add('hidden'); } }, 300);
  function frame() {
    if (s.phase !== 'running' || timerStart === null) return;
    const elapsed = performance.now() - timerStart;
    if (elapsed >= 300) { digits.textContent = ''; digits.classList.add('hidden'); timerFrame = 0; return; }
    digits.textContent = formatTime(Math.floor(elapsed / 10));
    timerFrame = requestAnimationFrame(frame);
  }
  timerFrame = requestAnimationFrame(frame);
}

function protectPrivacy() {
  let changed = false;
  if (hold !== null || state.session?.kind === 'impostor' && state.session.phase === 'reveal') { conceal(); changed = true; }
  const s = state.session;
  if (s?.kind === 'thought' && s.phase === 'answer') { s.phase = 'pass'; changed = true; }
  if (s?.kind === 'timer' && s.phase === 'running') { interruptCurrentTimer(); changed = true; }
  if (s?.kind === 'taboo' && s.phase === 'playing') { cancelAnimationFrame(timerFrame); timerFrame=0; changed = true; }
  if (changed) { persist(); if (route === '/play') render(false); }
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') protectPrivacy(); else if (route === '/play' && state.session?.kind === 'taboo' && state.session.phase === 'playing') startTabooClock(); });
window.addEventListener('blur', protectPrivacy);
window.addEventListener('pagehide', () => { protectPrivacy(); persist(); setAwake(false); });
window.addEventListener('pageshow', () => { setAwake(route === '/play' && Boolean(isActive())); if (route === '/play' && state.session?.kind === 'taboo' && state.session.phase === 'playing') startTabooClock(); });
window.addEventListener('focus', () => { if (route === '/play' && state.session?.kind === 'taboo' && state.session.phase === 'playing') startTabooClock(); });
window.addEventListener('popstate', () => {
  const requested = location.hash.slice(1) || '/';
  if (route === '/play' && isActive()) {
    history.pushState({ route }, '', '#/play');
    if (modal.open) { modal.close(); return; }
    leave(requested === '/play' ? '/' : requested);
    return;
  }
  conceal();
  if (state.session?.kind === 'thought' && state.session.phase === 'answer') state.session.phase = 'pass';
  interruptCurrentTimer(); persist();
  route = /^\/(players|settings|play|setup\/(impostor|thought|timer|taboo))$/.test(requested) ? requested : '/';
  if (route === '/play' && !state.session) route = '/';
  render();
  if (route === '/play' && state.session?.kind === 'taboo' && state.session.phase === 'playing') startTabooClock();
});

// A launch or refresh always starts with a neutral screen, never a secret.
history.replaceState({ route: '/' }, '', '#/');
persist(); render(false);
initPlatform({
  onInstallAvailable(value) { installAvailable = value; if (route === '/settings') render(false); },
  onOfflineReady(value) { offlineReady = value; if (route === '/settings') render(false); },
  onUpdateReady() { if (route !== '/play') toast('Atualização pronta. Feche e abra o app quando terminar de jogar.'); },
});
offlineReady = isOfflineReady();
