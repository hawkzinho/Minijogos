const STATE_KEY = 'minijogos.state.v1';
const BACKUP_KEY = STATE_KEY + '.backup';
const DATABASE = 'minijogos';
let revision = 0;
let databasePromise;
let writeQueue = Promise.resolve();

function checksum(text) {
  let hash = 2166136261;
  for (let i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
  return (hash >>> 0).toString(16);
}

function decode(value) {
  try {
    const record = typeof value === 'string' ? JSON.parse(value) : value;
    if (record?.schema !== 1 || !Number.isSafeInteger(record.revision) || typeof record.payload !== 'string' || checksum(record.payload) !== record.checksum) return null;
    const state = JSON.parse(record.payload);
    return state && typeof state === 'object' && !Array.isArray(state) ? { ...record, state } : null;
  } catch { return null; }
}

function localRead(key) {
  try { return decode(localStorage.getItem(key)); } catch { return null; }
}

function openDatabase() {
  if (databasePromise) return databasePromise;
  databasePromise = new Promise((resolve, reject) => {
    if (!globalThis.indexedDB) { reject(new Error('IndexedDB indisponível.')); return; }
    const request = indexedDB.open(DATABASE, 1);
    let expired = false;
    const timeout = setTimeout(() => { expired = true; reject(new Error('Armazenamento ocupado.')); }, 1500);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains('snapshots')) request.result.createObjectStore('snapshots');
    };
    request.onsuccess = () => {
      clearTimeout(timeout);
      if (expired) { request.result.close(); return; }
      request.result.onversionchange = () => { request.result.close(); databasePromise = undefined; };
      resolve(request.result);
    };
    request.onerror = () => { clearTimeout(timeout); reject(request.error); };
    request.onblocked = () => { expired = true; clearTimeout(timeout); reject(new Error('Armazenamento bloqueado.')); };
  }).catch(error => { databasePromise = undefined; throw error; });
  return databasePromise;
}

async function databaseRecord(record) {
  const database = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction('snapshots', record ? 'readwrite' : 'readonly');
    const store = transaction.objectStore('snapshots');
    const request = record ? store.put(record, 'current') : store.get('current');
    const timeout = setTimeout(() => { try { transaction.abort(); } catch {} reject(new Error('Armazenamento ocupado.')); }, 1500);
    transaction.oncomplete = () => { clearTimeout(timeout); resolve(record ? true : request.result); };
    transaction.onabort = transaction.onerror = () => { clearTimeout(timeout); reject(transaction.error); };
  });
}

export async function loadState(defaultState) {
  const records = [localRead(STATE_KEY), localRead(BACKUP_KEY)];
  try { records.push(decode(await databaseRecord())); } catch {}
  const newest = records.filter(Boolean).sort((a, b) => b.revision - a.revision)[0];
  if (!newest) return structuredClone(defaultState);
  revision = newest.revision;
  return newest.state;
}

export function saveState(state) {
  // The synchronous checkpoint survives the process being killed before the
  // IndexedDB transaction finishes. The queued copy cannot be mutated by callers.
  let record;
  try {
    const payload = JSON.stringify(state);
    record = { schema: 1, revision: Math.max(Date.now(), revision + 1), payload, checksum: checksum(payload) };
    revision = record.revision;
  } catch { return Promise.resolve(false); }
  let localSaved = false;
  try {
    const previous = localStorage.getItem(STATE_KEY);
    if (decode(previous)) {
      try { localStorage.setItem(BACKUP_KEY, previous); } catch {}
    }
    localStorage.setItem(STATE_KEY, JSON.stringify(record));
    localSaved = true;
  } catch {}
  writeQueue = writeQueue.catch(() => false).then(() => databaseRecord(record)).catch(() => localSaved);
  return writeQueue;
}

let wantsAwake = false;
let sentinel = null;
let wakeRequest = null;
let wakeListenerAdded = false;

async function reconcileWakeLock() {
  if (!wantsAwake || document.visibilityState !== 'visible') {
    const previous = sentinel;
    sentinel = null;
    try { await previous?.release(); } catch {}
    return;
  }
  if (sentinel || wakeRequest || !navigator.wakeLock) return wakeRequest;
  wakeRequest = navigator.wakeLock.request('screen').then(async lock => {
    if (!wantsAwake || document.visibilityState !== 'visible') { await lock.release(); return; }
    sentinel = lock;
    lock.addEventListener('release', () => { if (sentinel === lock) sentinel = null; }, { once: true });
  }).catch(() => {}).finally(() => { wakeRequest = null; });
  return wakeRequest;
}

export async function setAwake(active) {
  wantsAwake = Boolean(active);
  if (typeof document === 'undefined' || typeof navigator === 'undefined') return;
  if (!wakeListenerAdded) {
    document.addEventListener('visibilitychange', () => { void reconcileWakeLock(); });
    window.addEventListener('pagehide', () => {
      const previous = sentinel;
      sentinel = null;
      void previous?.release().catch(() => {});
    });
    window.addEventListener('pageshow', () => { void reconcileWakeLock(); });
    wakeListenerAdded = true;
  }
  await reconcileWakeLock();
}

let installPrompt = null;
let offlineReady = false;
let initialized = false;
let callbacks = {};

export function isOffline() { return globalThis.navigator?.onLine === false; }
export function isOfflineReady() { return offlineReady; }

function reportOfflineReady(value) {
  offlineReady = value;
  callbacks.onOfflineReady?.(value);
}

function checkWorker(worker) {
  if (!worker) return;
  const channel = new MessageChannel();
  const timeout = setTimeout(() => { channel.port1.close(); }, 3000);
  channel.port1.onmessage = event => {
    clearTimeout(timeout);
    channel.port1.close();
    reportOfflineReady(event.data?.ready === true);
  };
  worker.postMessage({ type: 'CACHE_STATUS' }, [channel.port2]);
}

export async function initPlatform(options = {}) {
  callbacks = options;
  if (initialized) {
    callbacks.onInstallAvailable?.(Boolean(installPrompt));
    callbacks.onOfflineReady?.(offlineReady);
    return;
  }
  initialized = true;
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    installPrompt = event;
    callbacks.onInstallAvailable?.(true);
  });
  window.addEventListener('appinstalled', () => {
    installPrompt = null;
    callbacks.onInstallAvailable?.(false);
    navigator.storage?.persist?.().catch(() => {});
  });
  if (!('serviceWorker' in navigator)) return;
  navigator.serviceWorker.addEventListener('message', event => {
    if (event.data?.type === 'OFFLINE_READY') reportOfflineReady(true);
  });
  navigator.serviceWorker.addEventListener('controllerchange', () => checkWorker(navigator.serviceWorker.controller));
  try {
    const workerURL = new URL('../sw.js', import.meta.url);
    const registration = await navigator.serviceWorker.register(workerURL, { scope: new URL('./', workerURL).pathname, updateViaCache: 'none' });
    if (registration.waiting) callbacks.onUpdateReady?.();
    checkWorker(registration.active);
    registration.addEventListener('updatefound', () => {
      const worker = registration.installing;
      worker?.addEventListener('statechange', () => {
        if (worker.state === 'installed' && navigator.serviceWorker.controller) callbacks.onUpdateReady?.();
        if (worker.state === 'activated') checkWorker(worker);
      });
    });
  } catch { reportOfflineReady(false); }
}

export async function installApp() {
  if (!installPrompt) return 'unavailable';
  const prompt = installPrompt;
  installPrompt = null;
  callbacks.onInstallAvailable?.(false);
  try {
    await prompt.prompt();
    const choice = await prompt.userChoice;
    return choice?.outcome === 'accepted' ? 'accepted' : 'dismissed';
  } catch { return 'unavailable'; }
}
