import { WORDS, QUESTIONS } from './content.js';

export const POINTS_PER_MATCH = 1;
const UINT_RANGE = 0x100000000;

/** Rejection sampling avoids the bias introduced by a plain modulo. */
export function randomInt(maxExclusive) {
  if (!Number.isInteger(maxExclusive) || maxExclusive < 1 || maxExclusive > UINT_RANGE) {
    throw new RangeError('Limite de sorteio inválido.');
  }
  const limit = UINT_RANGE - (UINT_RANGE % maxExclusive);
  const values = new Uint32Array(1);
  do { globalThis.crypto.getRandomValues(values); } while (values[0] >= limit);
  return values[0] % maxExclusive;
}

export function shuffle(items) {
  const result = [...items];
  for (let index = result.length - 1; index > 0; index--) {
    const other = randomInt(index + 1);
    [result[index], result[other]] = [result[other], result[index]];
  }
  return result;
}

/** Empty categories means Todas. History is JSON-safe and mutated at draw time,
 * so skipping, abandoning, or reloading cannot make a drawn item unused.
 * `used` tracks this cycle; `recent` contains all known IDs, oldest first.
 */
export function drawItem(bank, selectedCategories = [], history = {}) {
  const pool = bank.filter(item => !selectedCategories.length || selectedCategories.includes(item.category));
  if (!pool.length) throw new Error('Selecione uma categoria com conteúdo disponível.');
  const bankIds = new Set(bank.map(item => item.id));
  history.used = [...new Set(Array.isArray(history.used) ? history.used : [])].filter(id => bankIds.has(id));
  history.recent = [...new Set(Array.isArray(history.recent) ? history.recent : [])].filter(id => bankIds.has(id));
  let used = new Set(history.used);
  let available = pool.filter(item => !used.has(item.id));
  if (!available.length) {
    const poolIds = new Set(pool.map(item => item.id));
    history.used = history.used.filter(id => !poolIds.has(id));
    available = pool;
  }
  const recency = new Map(history.recent.map((id, index) => [id, index]));
  const neverUsed = available.filter(item => !recency.has(item.id));
  // New content is equally likely. Later cycles shuffle a band of the oldest
  // items, so the last few draws do not immediately reappear after a reset.
  const candidates = neverUsed.length ? neverUsed : [...available]
    .sort((a, b) => recency.get(a.id) - recency.get(b.id))
    .slice(0, Math.max(1, Math.ceil(available.length / 4)));
  const item = candidates[randomInt(candidates.length)];
  history.used.push(item.id);
  history.recent = history.recent.filter(id => id !== item.id);
  history.recent.push(item.id);
  return item;
}

export function normalizeText(text) {
  return String(text ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('pt-BR').replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .trim().replace(/\s+/g, ' ');
}

const ALIAS_GROUPS = [
  ['coca cola', 'coca', 'cocacola', 'coke'],
  ['cristiano ronaldo', 'cr7', 'cristiano'],
  ['neymar', 'neimar', 'neymar jr', 'neymar junior'],
  ['lionel messi', 'messi', 'leo messi', 'leonel messi'],
  ['ronaldo fenomeno', 'ronaldo nazario', 'fenomeno'],
  ['cachorro', 'dog', 'cao'], ['gato', 'cat'],
  ['mcdonalds', 'mc donalds', 'mcdonald s', 'mc donald s', 'mcdonald', 'mc donald', 'mec'],
  ['burger king', 'bk', 'burguer king'],
  ['kfc', 'kentucky fried chicken'], ['subway', 'sub way'],
  ['playstation', 'play station', 'ps'],
  ['counter strike', 'cs', 'counterstrike'],
  ['counter strike 2', 'cs2', 'cs 2'],
  ['league of legends', 'lol'], ['grand theft auto', 'gta'],
  ['grand theft auto v', 'gta v', 'gta 5'], ['minecraft', 'mine craft'],
  ['free fire', 'freefire'], ['fortnite', 'fort night'],
  ['call of duty', 'cod'], ['rocket league', 'rocketleague'],
  ['red dead redemption 2', 'rdr2', 'rdr 2'],
  ['the last of us', 'tlou'], ['the legend of zelda', 'zelda'],
  ['homem aranha', 'spider man', 'spiderman'],
  ['homem de ferro', 'iron man', 'ironman'],
  ['capitao america', 'captain america'],
  ['os vingadores', 'vingadores', 'avengers', 'the avengers'],
  ['o senhor dos aneis', 'senhor dos aneis', 'lord of the rings', 'the lord of the rings'],
  ['game of thrones', 'got'], ['harry potter', 'harry poter'],
  ['velozes e furiosos', 'fast and furious'],
  ['estados unidos', 'eua', 'usa', 'united states', 'united states of america'],
  ['reino unido', 'uk', 'united kingdom'],
  ['brasil', 'brazil'], ['japao', 'japan'], ['alemanha', 'germany'],
  ['espanha', 'spain'], ['franca', 'france'], ['italia', 'italy'],
  ['inglaterra', 'england'], ['portugal', 'pt'],
  ['teletransporte', 'teleportar', 'teletransportar', 'teleportation', 'teleport'],
  ['invisibilidade', 'ficar invisivel', 'ser invisivel', 'invisibility'],
  ['voar', 'poder voar', 'capacidade de voar', 'fly', 'flying'],
  ['ler mentes', 'ler pensamentos', 'leitura de mentes', 'telepatia', 'mind reading'],
  ['viagem no tempo', 'viajar no tempo', 'time travel'],
  ['sao paulo', 'sao paulo fc', 'spfc'], ['flamengo', 'mengao'],
  ['corinthians', 'corintians', 'timao'], ['palmeiras', 'verdao'],
  ['botafogo', 'fogao'], ['atletico mineiro', 'atletico mg', 'galo'],
  ['paris saint germain', 'psg'], ['manchester united', 'man united'],
  ['barcelona', 'barca'], ['real madrid', 'real madri'],
  ['anitta', 'anita'], ['ludmilla', 'ludmila'],
  ['the weeknd', 'weeknd', 'the weekend'],
  ['michael jackson', 'michael jakson'],
  ['iphone', 'i phone'], ['samsung', 'sansung'],
  ['whatsapp', 'whats app', 'whats', 'zap', 'zapzap'],
  ['instagram', 'insta'], ['tiktok', 'tik tok'],
  ['youtube', 'you tube'], ['twitter', 'x twitter'],
  ['mussarela', 'muçarela', 'mucarela', 'mozarela', 'mozzarella'],
  ['calabresa', 'calabreza'], ['strogonoff', 'estrogonofe', 'stroganoff'],
  ['sorvete', 'ice cream'], ['chocolate', 'chocolat'],
];
const ALIASES = new Map(ALIAS_GROUPS.flatMap(group => group.map(alias => [normalizeText(alias), normalizeText(group[0])])));

function canonicalText(text) {
  const normalized = normalizeText(text);
  return ALIASES.get(normalized) ?? normalized;
}

function oneEditApart(left, right) {
  if (Math.abs(left.length - right.length) > 1) return false;
  if (left.length === right.length) {
    const differences = [];
    for (let index = 0; index < left.length; index++) if (left[index] !== right[index]) differences.push(index);
    // A final-letter change frequently means another name (Fernando/Fernanda)
    // or another real word, so keep those answers separate.
    if (differences.length === 1) return left.length >= 7 && differences[0] < left.length - 1;
    return differences.length === 2 && differences[1] === differences[0] + 1
      && left[differences[0]] === right[differences[1]] && left[differences[1]] === right[differences[0]];
  }
  const [shorter, longer] = left.length < right.length ? [left, right] : [right, left];
  let index = 0;
  while (index < shorter.length && shorter[index] === longer[index]) index++;
  return shorter.slice(index) === longer.slice(index + 1);
}

/** Deliberately cautious: aliases first; at most one typo in a sufficiently
 * long word, with a stable prefix. Numbers and negations must stay identical.
 */
export function equivalentAnswers(left, right) {
  if (String(left).startsWith('player:') || String(right).startsWith('player:')) return left === right;
  const a = canonicalText(left), b = canonicalText(right);
  if (!a || !b) return false;
  if (a === b) return true;
  if (Math.min(a.length, b.length) < 6 || a.slice(0, 2) !== b.slice(0, 2)) return false;
  if ((a.match(/\d+/g) ?? []).join('|') !== (b.match(/\d+/g) ?? []).join('|')) return false;
  const protectedWords = /\b(nao|nunca|sem|com|contra)\b/g;
  if ((a.match(protectedWords) ?? []).join('|') !== (b.match(protectedWords) ?? []).join('|')) return false;
  const wordsA = a.split(' '), wordsB = b.split(' ');
  if (wordsA.length !== wordsB.length) return false;
  let editedWords = 0;
  for (let index = 0; index < wordsA.length; index++) {
    if (wordsA[index] === wordsB[index]) continue;
    if (++editedWords > 1 || Math.min(wordsA[index].length, wordsB[index].length) < 6
      || !oneEditApart(wordsA[index], wordsB[index])) return false;
  }
  return editedWords === 1;
}

export function canonicalAnswer(text, player, isGroup = false, players = []) {
  const normalized = normalizeText(text);
  if (isGroup) {
    if (['eu', 'eu mesmo', 'eu mesma'].includes(normalized)) return `player:${player.id}`;
    const exact = players.find(candidate => normalizeText(candidate.name) === normalized);
    if (exact) return `player:${exact.id}`;
    const close = players.filter(candidate => equivalentAnswers(candidate.name, normalized));
    if (close.length === 1) return `player:${close[0].id}`;
  }
  return canonicalText(text);
}

export function groupAnswers(answers, players, isGroup = false) {
  const groups = [];
  for (const answer of answers) {
    const player = players.find(candidate => candidate.id === answer.playerId);
    if (!player) throw new Error('Resposta de jogador desconhecido.');
    const key = canonicalAnswer(answer.text, player, isGroup, players);
    const group = groups.find(candidate => candidate.keys.every(existing => equivalentAnswers(existing, key)));
    if (group) {
      group.keys.push(key);
      group.playerIds.push(player.id);
      group.answers.push({ ...answer });
    } else {
      const namedPlayer = key.startsWith('player:') && players.find(candidate => `player:${candidate.id}` === key);
      groups.push({ key, keys: [key], label: namedPlayer ? namedPlayer.name : answer.text,
        playerIds: [player.id], answers: [{ ...answer }], points: 0 });
    }
  }
  return groups.map(({ keys, ...group }) => ({ ...group, points: group.playerIds.length >= 2 ? POINTS_PER_MATCH : 0 }));
}

function copyPlayers(players) {
  if (!Array.isArray(players) || players.length < 3 || players.length > 7) throw new Error('Cadastre de 3 a 7 jogadores.');
  if (new Set(players.map(player => player.id)).size !== players.length
    || players.some(player => !player.id || !normalizeText(player.name))
    || new Set(players.map(player => normalizeText(player.name))).size !== players.length) {
    throw new Error('Use nomes e identificadores únicos para os jogadores.');
  }
  return players.map(player => ({ id: player.id, name: player.name.trim() }));
}

export function createImpostor(players, settings, history = {}) {
  const roster = copyPlayers(players);
  if (!Number.isInteger(settings.impostors) || settings.impostors < 1 || settings.impostors > roster.length - 2) {
    throw new Error('A rodada precisa de pelo menos dois jogadores normais.');
  }
  return { kind: 'impostor', phase: 'pass', players: roster, settings: { ...settings, categories: [...settings.categories] },
    item: drawItem(WORDS, settings.categories, history), impostorIds: shuffle(roster).slice(0, settings.impostors).map(player => player.id),
    starterId: roster[randomInt(roster.length)].id, index: 0 };
}

export function openImpostor(session) {
  if (session.kind !== 'impostor' || session.phase !== 'pass') return false;
  session.phase = 'reveal';
  return true;
}

export function finishImpostorReveal(session) {
  if (session.kind !== 'impostor' || session.phase !== 'reveal') return false;
  session.index++;
  session.phase = session.index === session.players.length ? 'discussion' : 'pass';
  return true;
}

export function backImpostor(session) {
  if (session.kind !== 'impostor' || !['pass', 'discussion'].includes(session.phase) || session.index < 1) return false;
  session.index--;
  session.phase = 'pass';
  return true;
}

export function revealImpostorResult(session) {
  if (session.kind !== 'impostor' || session.phase !== 'discussion') return false;
  session.phase = 'result';
  return true;
}

export function createThought(players, settings, history = {}, previous = null) {
  const roster = copyPlayers(players);
  if (![10, 20, 30].includes(settings.target)) throw new Error('Escolha 10, 20 ou 30 pontos para vencer.');
  return { kind: 'thought', phase: 'pass', players: roster, settings: { ...settings, categories: [...settings.categories] },
    question: drawItem(QUESTIONS, settings.categories, history), index: 0, answers: [],
    scores: Object.fromEntries(roster.map(player => [player.id, previous?.scores[player.id] ?? 0])),
    groups: [], winners: [], round: (previous?.round ?? 0) + 1 };
}

export function openThought(session) {
  if (session.kind !== 'thought' || session.phase !== 'pass') return false;
  session.phase = 'answer';
  return true;
}

export function submitThought(session, text, expectedPlayerId = session.players[session.index]?.id) {
  if (session.kind !== 'thought' || session.phase !== 'answer' || session.players[session.index]?.id !== expectedPlayerId) return false;
  const answer = String(text ?? '').trim().replace(/\s+/g, ' ');
  if (!normalizeText(answer) || answer.length > 80) return false;
  session.answers.push({ playerId: expectedPlayerId, text: answer });
  session.index++;
  session.phase = session.index === session.players.length ? 'result' : 'pass';
  if (session.phase === 'result') {
    session.groups = groupAnswers(session.answers, session.players, session.question.group);
    for (const group of session.groups) for (const id of group.playerIds) session.scores[id] += group.points;
    const highest = Math.max(...Object.values(session.scores));
    if (highest >= session.settings.target) session.winners = session.players.filter(player => session.scores[player.id] === highest).map(player => player.id);
  }
  return true;
}

/** Used for both a confirmed skip and the next completed round. Scores already
 * awarded in a result screen remain awarded; unfinished answers award nothing.
 */
export function nextThought(session, history = {}) {
  if (session.kind !== 'thought' || session.winners.length) throw new Error('Esta partida já terminou.');
  return createThought(session.players, session.settings, history, session);
}

export function drawTarget(recentTargets = []) {
  const recent = recentTargets.slice(-5).filter(Number.isInteger);
  const candidates = [];
  for (let target = 200; target <= 1500; target++) {
    if (recent.every(previous => Math.abs(previous - target) >= 75)) candidates.push(target);
  }
  const target = candidates[randomInt(candidates.length)];
  recentTargets.push(target);
  recentTargets.splice(0, Math.max(0, recentTargets.length - 5));
  return target;
}

export function createTimer(players, recentTargets = [], participants = null) {
  const roster = copyPlayers(players);
  const ids = participants?.map(player => typeof player === 'string' ? player : player.id);
  const active = ids ? roster.filter(player => ids.includes(player.id)) : roster;
  if (active.length < 2 || (ids && (active.length !== ids.length || new Set(ids).size !== ids.length))) {
    throw new Error('O desempate precisa de pelo menos dois jogadores válidos.');
  }
  return { kind: 'timer', phase: 'ready', players: roster, order: shuffle(active),
    targetCs: drawTarget(recentTargets), index: 0, results: [], winners: [] };
}

export function startTimer(session) {
  if (session.kind !== 'timer' || session.phase !== 'ready') return false;
  session.phase = 'running';
  return true;
}

function finishTimerAttempt(session, result) {
  session.results.push(result);
  session.index++;
  session.phase = session.index === session.order.length ? 'result' : 'ready';
  if (session.phase === 'result') {
    const valid = session.results.filter(attempt => !attempt.interrupted);
    const closest = Math.min(...valid.map(attempt => attempt.difference));
    session.winners = valid.filter(attempt => attempt.difference === closest).map(attempt => attempt.playerId);
  }
  return true;
}

/** The UI provides performance.now() elapsed milliseconds. Ranking uses the
 * same rounded integer centiseconds shown to players, including exact ties.
 */
export function recordTimer(session, elapsedMs, expectedPlayerId = session.order[session.index]?.id) {
  if (session.kind !== 'timer' || session.phase !== 'running' || session.order[session.index]?.id !== expectedPlayerId
    || !Number.isFinite(elapsedMs) || elapsedMs < 0) return false;
  const centiseconds = Math.round(elapsedMs / 10);
  return finishTimerAttempt(session, { playerId: expectedPlayerId, centiseconds, difference: Math.abs(centiseconds - session.targetCs) });
}

export function interruptTimer(session) {
  if (session.kind !== 'timer' || session.phase !== 'running') return false;
  return finishTimerAttempt(session, { playerId: session.order[session.index].id, centiseconds: null, difference: null, interrupted: true });
}

export function ranking(session) {
  return [...session.results].sort((a, b) => (a.interrupted ? Infinity : a.difference) - (b.interrupted ? Infinity : b.difference));
}

export function formatTime(centiseconds) {
  if (!Number.isFinite(centiseconds) || centiseconds < 0) return '—';
  const value = Math.round(centiseconds);
  return `${String(Math.floor(value / 100)).padStart(2, '0')}:${String(value % 100).padStart(2, '0')}`;
}
